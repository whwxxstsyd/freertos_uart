

#ifndef __BATTERY_H__
#define __BATTERY_H__


int battery_is_level();
int battery_is_charging();


#endif // __BATTERY_H__

