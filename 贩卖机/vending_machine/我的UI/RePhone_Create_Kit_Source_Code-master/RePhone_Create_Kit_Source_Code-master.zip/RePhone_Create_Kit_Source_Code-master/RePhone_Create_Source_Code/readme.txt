This example shows how to receive touch event and the x,y value from the board.

This example uses vm_touch_register_event_callback() to register touch handler.
When touch the LCD on the board, the touch event and (x,y) value will be sent to application to touch handler.

Just run this application, and observe monitor log.
