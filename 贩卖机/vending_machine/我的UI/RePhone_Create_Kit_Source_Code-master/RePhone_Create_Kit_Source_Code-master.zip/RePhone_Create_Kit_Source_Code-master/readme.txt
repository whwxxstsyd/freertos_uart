1. RePhone_Create_Source_Code
 - IDE Eclipse
 - RePhone Create Kit source code
 
2. These is a define in file "lcd_sitronix_st7789s.h", and need to sure the version of Xadow 1.54" Touchscreen. 
If the version is v1.0 choose "_TOUCH_SCREEN_V1_0_", else if the version is v1.1 choose "_TOUCH_SCREEN_V1_1_".