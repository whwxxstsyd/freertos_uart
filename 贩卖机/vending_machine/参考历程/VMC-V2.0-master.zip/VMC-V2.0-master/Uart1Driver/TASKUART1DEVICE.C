/****************************************Copyright (c)*************************************************
**                      Fujian Junpeng Communicaiton Technology Co.,Ltd.
**                               http://www.easivend.com.cn
**--------------File Info------------------------------------------------------------------------------
** File name:           TASKDEVICE
** Last modified Date:  2013-03-04
** Last Version:         
** Descriptions:        ����1����                     
**------------------------------------------------------------------------------------------------------
** Created by:          gzz
** Created date:        2013-03-04
** Version:             V2.0
** Descriptions:        The original version
**------------------------------------------------------------------------------------------------------
** Modified by:         
** Modified date:       
** Version:             
** Descriptions:        
********************************************************************************************************/
#include "..\config.h"
#include "TASKUART1DEVICE.H"
#include "SelectKey.h"
//#include "Xmt.h"



/*
#define COINDEV_MDB			2				//��ǰϵͳʶ�𵽵�Ӳ��������ΪMDB
#define BILLDEV_MDB			2				//��ǰϵͳʶ�𵽵�ֽ��������ΪMDB

#define READERDEV_MDB		2				//��ǰϵͳʶ�𵽵Ķ���������ΪMDB
 */

#define OFF_KEY			    0//��ͨ���̰���
#define SELECT_KEY			1//ѡ������
#define GEZIGUI		    	1//�������ӹ�






/*********************************************************************************************************
** Function name:       Uart1TaskDevice
** Descriptions:        �豸����:��Ҫ��������UART2�ϵ��豸����MDBЭ��,EVBЭ���
** input parameters:    pvData: û��ʹ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void Uart1TaskDevice(void *pvData)
{
	MessageKEYPack *AccepterMsg;
	MessageXMTPack *XMTPack;
	//MessageFSBillRecyclerPack *FSBillRecyclerMsg;
	unsigned char ComStatus;
	MessagePack *GeziMsg;
	uint8_t key=0xff;
	
	//��ǰѡ���豸������
	uint8_t NowSelectDev = 0;
	//���������豸
	uint8_t TempDev = 0,temp=0;
	uint8_t TempCtr = 1;
	//�������ӹ�
	uint8_t GeziCtr = 0;
	uint8_t rst=0;
	
	
	//���ѡ����������
	AccepterMsg = OSMboxPend(g_KEYMail,OS_TICKS_PER_SEC,&ComStatus);
	if(ComStatus == OS_NO_ERR)
	{
		if((AccepterMsg->KeyCmd)==MBOX_SELECTKEYINIT)
		{	
			//OSTimeDly(1000);
			TraceSelection("\r\n Taskpend selectinit"); 
			LCDNumberFontPrintf(40,LINE15,2,"SelectAccepter-1");	
			memset(&selKey,0,sizeof(selKey));
			SelectKey_InitProc();	
			UpdateSelectionLed(AccepterMsg);
			NowSelectDev = SELECT_KEY;			
		}
		else
		{
			NowSelectDev = 0;
		}
	}	
	else
	{
		NowSelectDev = 0;
	}
	OSTimeDly(2);
	//����¿�������
	if(SystemPara.XMTTemp==1)
	{
		LCDNumberFontPrintf(40,LINE15,2,"XMT-1");	
		TempDev=TEMPERATURE;
		Timer.getTempTimer = 10;
		OSTimeDly(2);
	}
	//�����ӹ����
	if(SystemPara.hefangGui==SERIAL_GEZI)
	{
		LCDNumberFontPrintf(40,LINE15,2,"GEZI-1");	
		GeziCtr = GEZIGUI;
		OSTimeDly(2);
	}
	//��鸻ʿ������
	if(SystemPara.BillRecyclerType == FS_BILLRECYCLER)
	{
		LCDNumberFontPrintf(40,LINE15,2,"FS-1");	
		OSTimeDly(200*2);
		FS_init();
	}
	
	
	while(1)
	{		
		if(NowSelectDev == SELECT_KEY)
		{
			//Trace("\r\n UART1TASK");
			//1.pollѡ������
			key=GetSelectKey();
			//�а������ϱ�����ֵ
			if(key != 0xff)
			{				
				MsgKEYBackPack.KeyBackCmd = MBOX_SELECTVALUE;	
				MsgKEYBackPack.selectInput = key;
				OSMboxPost(g_KEYBackMail,&MsgKEYBackPack);
				TraceSelection("\r\n Taskpkey=%d",key); 
				key=0xff;
				OSTimeDly(OS_TICKS_PER_SEC * 2);
			}
			//2.���ѡ����������
			AccepterMsg = OSMboxPend(g_KEYMail,OS_TICKS_PER_SEC/100,&ComStatus);
			//TraceSelection("\r\n Taskkeymail1=%d",ComStatus); 
			if(ComStatus == OS_NO_ERR)
			{
				//TraceSelection("\r\n Taskkeymail2=%d",AccepterMsg->KeyCmd); 
				if((AccepterMsg->KeyCmd)==MBOX_SELECTLIGHT)
				{	
					UpdateSelectionLed(AccepterMsg);
				}
			}	
		}
		//�¿���
		else if(TempDev==TEMPERATURE)
		{	
			if(Timer.getTempTimer==0)
			{
				Timer.getTempTimer = 10;
				temp=XMTMission_GetTemperature();
				Trace("\r\n temp=%d,GetPV=%d.%d,GetSV=%d.%d",temp,sysXMTMission.recPVTemp/10, sysXMTMission.recPVTemp%10,sysXMTMission.recSVTemp/10, sysXMTMission.recSVTemp%10);
			}
			OSTimeDly(2);
			//2.����¿�������
			XMTPack = OSMboxPend(g_XMTMail,OS_TICKS_PER_SEC/100,&ComStatus);
			//Trace("\r\n Taskkeymail1=%d",ComStatus); 
			if(ComStatus == OS_NO_ERR)
			{
				//Trace("\r\n Taskkeymail2=%d",XMTPack->KeyCmd); 
				if((XMTPack->KeyCmd)==MBOX_XMTSETTEMP)
				{	
					TempCtr = XMTMission_SetTemperatureS(XMTPack->temparater);
					if(TempCtr==0)//�ɹ�
					{
						MsgXMTPack.KeyBackCmd = MBOX_XMTTEMPOK;							
					}
					else//ʧ��
					{
						MsgXMTPack.KeyBackCmd = MBOX_XMTTEMPFAIL;	
					}
					OSMboxPost(g_XMTBackMail,&MsgXMTPack);
					OSTimeDly(2);
				}
			}
		}
		//�����ӹ�
		else if(GeziCtr == GEZIGUI)
		{
			//���պз����������  Add by liya 2014-01-20
			GeziMsg = OSMboxPend(g_HeFanGuiMail,OS_TICKS_PER_SEC/100,&ComStatus);
			if(ComStatus == OS_NO_ERR)
			{
				switch(GeziMsg->HeFanGuiHandle)	
				{
					case HEFANGUI_KAIMEN:
					case HEFANGUI_CHAXUN:
					case HEFANGUI_JIAREKAI:
					case HEFANGUI_JIAREGUAN:
					case HEFANGUI_ZHILENGKAI:
					case HEFANGUI_ZHILENGGUAN:
					case HEFANGUI_ZHAOMINGKAI:
					case HEFANGUI_ZHAOMINGGUAN:
						TraceChannel("recv..CMD    lvel=%d\r\n",GeziMsg->HeFanGuiHandle);
						rst = HeFanGuiDriver(GeziMsg->Binnum,GeziMsg->HeFanGuiHandle,GeziMsg->HeFanGuiNum,MsgAccepterPack.HeFanGuiBuf);
						TraceChannel("Task_res==%d\r\n",rst);
						MsgAccepterPack.HeFanGuiHandle = GeziMsg->HeFanGuiHandle;
						MsgAccepterPack.HeFanGuiRst = rst;
						OSMboxPost(g_HeFanGuiBackMail,&MsgAccepterPack);
						break;
				}
			}
			OSTimeDly(2);	
		}
		//��鸻ʿ������
		else if(SystemPara.BillRecyclerType == FS_BILLRECYCLER)
		{
			FS_poll();
			msleep(10);
		}
		else	
		{
			OSTimeDly(2);
		}

		//���ֽ��������
		/*FSBillRecyclerMsg = OSMboxPend(g_FSBillRecyclerMail,1,&ComStatus);
		if(ComStatus == OS_NO_ERR)
		{
			//ֽ�����������ұ�
			if(FSBillRecyclerMsg->BillBack == MBOX_FSBILLRECYPAYOUTNUM)
			{
				print_fs("\r\n TaskFSPay=%ld,Num=%d",FSBillRecyclerMsg->RecyPayoutMoney,FSBillRecyclerMsg->RecyPayoutNum);
                          PayoutMoney=(FSBillRecyclerMsg->RecyPayoutMoney)*(FSBillRecyclerMsg->RecyPayoutNum);
				//PayouBacktMoney=FS_dispense(PayoutMoney);
				MsgFSBillRecyclerPack.BillBackCmd = MBOX_FSBILLRECYPAYOUTSUCC;	
				MsgFSBillRecyclerPack.RecyPayoutMoneyBack=PayouBacktMoney;
				OSMboxPost(g_FSBillRecyclerBackMail,&MsgFSBillRecyclerPack);
			}
		}*/
		//OSTimeDly(50/5);
	}	
}
