/****************************************Copyright (c)*************************************************
**                      Fujian Junpeng Communicaiton Technology Co.,Ltd.
**                               http://www.easivend.com.cn
**--------------File Info------------------------------------------------------------------------------
** File name:           BUSINESS.C
** Last modified Date:  2013-03-06
** Last Version:        No
** Descriptions:        ��������                    
**------------------------------------------------------------------------------------------------------
** Created by:          gzz
** Created date:        2013-03-06
** Version:             V0.1
** Descriptions:        The original version        
********************************************************************************************************/
#include "..\config.h"
#include "BUSINESS.H"
#include "MAINTAIN.H"
#include "CHANNEL.h"
#include "LIFTTABLE.h"
#include "ACDC.h"



//extern SYSTEMPARAMETER SystemPara;
extern RTC_DATE RTCData;
extern RTC_DATE vmRTC;


#define VMC_FREE		  0                         //����״̬
#define VMC_CHAXUN	      1							//������ѯ״̬
#define VMC_CHAXUNHEFANG  2							//�з���Ų�ѯ״̬
#define VMC_SALE 	      3							//����״̬
#define VMC_OVERVALUE	  4							//��ֵ̫��
#define VMC_XUANHUO    	  5							//ѡ��
#define VMC_WUHUO    	  6							//�޻�
#define VMC_LESSMONEY 	  7							//Ǯ������Ʒ����
#define VMC_CHANGESHORT	  8							//��Ǯ����
#define VMC_READVENDFAIL  9							//�������ۿ�ʧ��
#define VMC_CHUHUO  	  10						//����
#define VMC_QUHUO  	  	  11						//ȡ��
#define VMC_CHUHUOFAIL 	  12						//����ʧ��
#define VMC_PAYOUT 	      13						//����
#define VMC_END 	      14						//��������
#define VMC_ERROR		  15                        //����״̬
#define VMC_ERRORSALE	  16                        //����ʱͶ��Ǯ�ҵ�״̬
#define VMC_ERRORPAYOUT	  17                        //����ʱ�����״̬
#define VMC_ERROREND	  18                        //����ʱ�������׵�״̬
#define VMC_WEIHU		  19                        //ά��״̬



char     	ChannelNum[3] = {0};//ѡ�����ֵ
char     	BinNum[2] = {0};//ѡ��з����ֵ
uint8_t	    channelInput = 0;
uint8_t     channelMode = 0;//0������ӱ��,1���뱾����Ʒ���
uint8_t	 	vmcStatus = VMC_FREE;//��ǰ״̬
uint8_t	 	vmcChangeLow = 0;//��Ǯ�Ƿ񲻹���1������,0����


uint32_t 	g_coinAmount = 0;   	 //��ǰͶ��Ӳ���ܽ��
uint32_t 	g_billAmount = 0;    //��ǰѹ��ֽ���ܽ��
uint32_t 	g_holdValue = 0;    //��ǰ�ݴ�ֽ�ҽ��
uint32_t 	g_readerAmount = 0; //��ǰ�������ܽ��

uint16_t	vmcColumn = 0;//��ǰ�������Ʒ���
uint32_t 	vmcPrice  = 0;//��ǰ�������Ʒ����
unsigned char transMul = 0;//��¼�ǵڼ��ν���
uint8_t hefangMode = 0;//1�����з������,0�����ۻ�������



uint32_t 	MoneyMaxin = 0;//���ν������Ͷ������
uint32_t 	PriceMaxin = 0;//��ǰ�����Ʒ����



extern void ClearDealPar(void);
extern void BillCoinCtr(uint8_t billCtr,uint8_t coinCtr,uint8_t readerCtr);
extern uint8_t SaleTimeSet(uint8_t haveSale);

volatile unsigned int GOCCHECKTIMEOUT;

/*********************************************************************************************************
** Function name:     	DispBusinessText
** Descriptions:	    ����ʱ��ʾ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispBusinessText(char *strlanguage,char *streng,char *rightstrlanguage,char *rightstreng)
{
	LCDDrawLine(0,LINE11);
	LCDSpecialPicPrintf(0,LINE12,1,2);//��ͷ	
	LCDPrintf(40,LINE12,0,SystemPara.Language,strlanguage);
	if(SystemPara.Language != 1)
		LCDPrintf(40,LINE14,0,SystemPara.Language,streng);
	if(strlen(rightstrlanguage)!=NULL)
	{
		LCDSpecialPicPrintf(112,LINE12,1,2);//��ͷ	
		LCDPrintf(152,LINE12,0,SystemPara.Language,rightstrlanguage);
		if(SystemPara.Language != 1)
			LCDPrintf(152,LINE14,0,SystemPara.Language,rightstreng);
	}
}

/*********************************************************************************************************
** Function name:     	DispBusinessText
** Descriptions:	    �彻��ʱ��ʾ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void CLrBusinessText()
{	
	LCDClearLineDraw(0,LINE11,1);
	LCDClearLineDraw(0,LINE12,3);	
}


/*********************************************************************************************************
** Function name:     	DispFreePage
** Descriptions:	    ����ҳ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispFreePage()
{
	char strlanguage[30] = {0};
	//char strone[30] = {0},strtwo[30] = {0};
	

	//LCDClrScreen();
	//Trace("\r\n RTC1-Time");
	RTCReadTime(&RTCData);
	OSTimeDly(2);
	//Trace("\r\n read=%d,%d,%d,%d,%d",RTCData.year,RTCData.month,RTCData.day,RTCData.hour,RTCData.minute);	
	//LCDPrintf(0,2,0,SystemPara.Language,"%d-%02d-%02d %02d:%02d:%02d",RTCData.year,RTCData.month,RTCData.day,RTCData.hour,RTCData.minute,RTCData.second);
	//LCDClrScreen();
	//LCDPutLOGOBmp(75,LINE1,SystemPara.Logo);	

	if(vmcChangeLow)
	{
		//Trace("\r\n RTC2-Time");
		RTCReadTime(&RTCData);
		OSTimeDly(2);
		//1������ʾ
		LCDSpecialPicPrintf(0,LINE2,4,2);//��ͷ 
		strcpy(strlanguage,BUSINESSERROR[1][20]); 
		LCDNumberFontPrintf(40,LINE2,2,strlanguage);
		strcpy(strlanguage,BUSINESSERROR[1][22]); 
		LCDNumberFontPrintf(40,LINE4,1,strlanguage);
		strcpy(strlanguage,BUSINESSERROR[SystemPara.Language][22]);
		LCDPrintf(40,LINE6,0,SystemPara.Language,strlanguage);
		//strcpy(strlanguage,BUSINESSERROR[SystemPara.Language][21]); 
		//LCDNumberFontPrintf(40,LINE6,1,strlanguage);
		//LCDClearLineDraw(0,LINE11,1);
		//�����¿������������¶�
		if(SystemPara.XMTTemp==1)
		{
			sprintf(strlanguage,"%d.%d \x92",sysXMTMission.recPVTemp/10, sysXMTMission.recPVTemp%10); 
			//LCDNumberFontPrintf(40,LINE4,1,strlanguage);
			LCDPrintf(40,LINE8,0,SystemPara.Language,strlanguage);
		}
		//2����
		LCDDrawLine(0,LINE11);
		//3ʱ������ 
		if((vmRTC.year != RTCData.year)||(vmRTC.month !=RTCData.month)||(vmRTC.day !=RTCData.day))
		{
			sprintf( strlanguage, "%04d", RTCData.year);
			LCDNumberFontPrintf(40,LINE12,2,strlanguage);
			sprintf( strlanguage, "%02d-%02d", RTCData.month,RTCData.day);
			LCDNumberFontPrintf(40,LINE14,2,strlanguage);
			vmRTC.year = RTCData.year;
			vmRTC.month =RTCData.month;
			vmRTC.day =RTCData.day;			
		}
		if((vmRTC.hour != RTCData.hour)||(vmRTC.minute !=RTCData.minute))
		{
			sprintf( strlanguage, "%02d:%02d", RTCData.hour,RTCData.minute);
			LCDNumberFontPrintf(96,LINE12,3,strlanguage);
			vmRTC.hour = RTCData.hour;
			vmRTC.minute =RTCData.minute;
		}
		
	}
	else
	{
		strcpy(strlanguage,BUSINESS[SystemPara.Language][6]); 
		LCDPrintf(72,LINE3,0,SystemPara.Language,strlanguage);
		//�����¿������������¶�
		if(SystemPara.XMTTemp==1)
		{
			sprintf(strlanguage,"%d.%d \x92",sysXMTMission.recPVTemp/10, sysXMTMission.recPVTemp%10); 
			//LCDNumberFontPrintf(40,LINE4,1,strlanguage);
			LCDPrintf(170,LINE6,0,SystemPara.Language,strlanguage);
		}
		//2ʱ������ 
		if((vmRTC.year != RTCData.year)||(vmRTC.month !=RTCData.month)||(vmRTC.day !=RTCData.day))
		{
			LCDNumberFontPrintf(80,LINE7,2,"%04d-%02d-%02d",RTCData.year,RTCData.month,RTCData.day);
			vmRTC.year = RTCData.year;
			vmRTC.month =RTCData.month;
			vmRTC.day =RTCData.day;
		}
		if((vmRTC.hour != RTCData.hour)||(vmRTC.minute !=RTCData.minute))
		{
			LCDNumberFontPrintf(60,LINE9,4,"%02d:%02d",RTCData.hour,RTCData.minute);
			vmRTC.hour = RTCData.hour;
			vmRTC.minute =RTCData.minute;
		}
	}	
}
/*********************************************************************************************************
** Function name:     	DispFreePage
** Descriptions:	    ����ҳ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispErrPage()
{
	char strlanguage[30] = {0};

	//Trace("\r\n RTC2-Time");
	RTCReadTime(&RTCData);
	OSTimeDly(2);
	//1������ʾ
	LCDSpecialPicPrintf(0,LINE2,3,2);//��ͷ 
	strcpy(strlanguage,BUSINESSERROR[SystemPara.Language][19]); 
	//LCDNumberFontPrintf(40,LINE2,2,strlanguage);
	LCDPrintf(40,LINE2,0,SystemPara.Language,strlanguage);
	strcpy(strlanguage,BUSINESSERROR[SystemPara.Language][0]); 
	//LCDNumberFontPrintf(40,LINE4,1,strlanguage);
	LCDPrintf(40,LINE4,0,SystemPara.Language,strlanguage);
	//LCDClearLineDraw(0,LINE11,1);
	//�����¿������������¶�
	if(SystemPara.XMTTemp==1)
	{
		sprintf(strlanguage,"%d.%d \x92",sysXMTMission.recPVTemp/10, sysXMTMission.recPVTemp%10); 
		//LCDNumberFontPrintf(40,LINE4,1,strlanguage);
		LCDPrintf(40,LINE6,0,SystemPara.Language,strlanguage);
	}
	//2����
	LCDDrawLine(0,LINE11);
	//3ʱ������ 
	if((vmRTC.year != RTCData.year)||(vmRTC.month !=RTCData.month)||(vmRTC.day !=RTCData.day))
	{
		sprintf( strlanguage, "%04d", RTCData.year);
		LCDNumberFontPrintf(40,LINE12,2,strlanguage);
		sprintf( strlanguage, "%02d-%02d", RTCData.month,RTCData.day);
		LCDNumberFontPrintf(40,LINE14,2,strlanguage);
		vmRTC.year = RTCData.year;
		vmRTC.month =RTCData.month;
		vmRTC.day =RTCData.day;
	}
	if((vmRTC.hour != RTCData.hour)||(vmRTC.minute !=RTCData.minute))
	{
		sprintf( strlanguage, "%02d:%02d", RTCData.hour,RTCData.minute);
		LCDNumberFontPrintf(96,LINE12,3,strlanguage);
		vmRTC.hour = RTCData.hour;
		vmRTC.minute =RTCData.minute;
	}
	
}



//�����Ҫʹ�õĻ���
uint16_t GetColumnNum(char *ChannelNum,uint8_t subType)
{
	uint16_t columnNo;
	//����������ߺз���
	if( (subType==1)||(SystemPara.hefangGui==1) )
	{
		if(ChannelNum[0]=='A')
		{
			//Trace("\r\n 1");
			columnNo = (1*100)+(ChannelNum[1]-'0')*10+(ChannelNum[2]-'0');	
		}
		else if(ChannelNum[0]=='B') 	
		{
			//Trace("\r\n 2");	
			columnNo = (2*100)+(ChannelNum[1]-'0')*10+(ChannelNum[2]-'0');	
		}
		else
		{
			columnNo = (ChannelNum[0]-'0')*100+(ChannelNum[1]-'0')*10+(ChannelNum[2]-'0');	
		}
	}
	//ֻ������
	else
		columnNo = (1*100)+(ChannelNum[0]-'0')*10+(ChannelNum[1]-'0');	
	//Trace("\r\n ChannelNum=%s,column=%ld",ChannelNum,columnNo);
	return columnNo;
}


//�����Ҫʹ�õĺз������
uint16_t GetHefangNum(char *ChannelNum,char *BinNum)
{
	uint16_t columnNo;
	
	columnNo = ((BinNum[0]-'0')*1000)+((BinNum[1]-'0')*100)+((ChannelNum[0]-'0')*10)+(ChannelNum[1]-'0');	
	return columnNo;
}



/*********************************************************************************************************
** Function name:     	DispChaxunFreePage
** Descriptions:	    ����ҳ���ѯ����״̬��ҳ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChaxunFreePage()
{	
	LCDClrScreen();
	//RTCReadTime(&RTCData);
	//OSTimeDly(2);

	LCDNumberFontPrintf(80,LINE3,2,"%04d-%02d-%02d",RTCData.year,RTCData.month,RTCData.day);
	LCDNumberFontPrintf(60,LINE5,4,"%02d:%02d",RTCData.hour,RTCData.minute);	
}


/*********************************************************************************************************
** Function name:     	DispChaxunPage
** Descriptions:	    �����ѯ������ҳ��
** input parameters:    keyMode=1,�������������ѡ����ť���µ�,
                               =2,�������������С���̰��µ�,
                               =0����û�а�������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChaxunPage(uint8_t *keyValue,uint8_t *keyMode)
{
	char strlanguage[30] = {0},streng[30] = {0};
	//char tempstrlanguage[30] = {0},tempstreng[30] = {0};
	uint8_t columnState=0,isColumn=0;
	uint16_t columnNo=0;
	uint32_t debtMoney=0;
	uint8_t channel_id=0;

	if(*keyMode == 2)
	{
		if((*keyValue == 'C')||(*keyValue == 'E'))
		{
			channelInput = 0;
			memset(ChannelNum,0,sizeof(ChannelNum));
			if(GetAmountMoney() > 0)
			{				
				vmcStatus = VMC_SALE;
			}
			else
			{
				ClearDealPar(); 	
				CLrBusinessText();
				vmcStatus = VMC_FREE;
			}
			return;
		}		
	}
	//ʹ�ü��̰���
	if(*keyMode == 2)		
	{
		ChannelNum[channelInput++] = *keyValue; 
		strcpy(strlanguage,BUSINESS[SystemPara.Language][0]);		
		//�з��񶼿���
		//��������
		if(SystemPara.SubBinOpen==1)
		{
			if(ChannelNum[0]=='.')
			{
				ChannelNum[0]='A';	
			}
			else if(ChannelNum[0]=='D') 	
			{
				ChannelNum[0]='B';	
			}
			strcat(strlanguage,ChannelNum);
		}	
		//ֻ������
		else
		{
			strcat(strlanguage,ChannelNum);
		}
		strcpy(streng,BUSINESS[1][0]);	
		strcat(streng,ChannelNum);	
		DispBusinessText(strlanguage,streng,"","");

		
		//��������,���ߺз���
		if( (SystemPara.SubBinOpen==1)||(SystemPara.hefangGui==1) )
		{
			//Trace("\r\n input=%d,ChannelNum=%s",channelInput,ChannelNum);
			if(channelInput >= 3)
			{
				//ȥ���Ұ����Ļ�����ѯ
				if
				(
					(SystemPara.SubBinOpen==0)				
					&&(
						(ChannelNum[0]=='.')||(ChannelNum[0]=='D')||(ChannelNum[1]=='.')||(ChannelNum[1]=='D')||
						(ChannelNum[2]=='.')||(ChannelNum[2]=='D')
					  )

				)  
				{
					columnState = 5;
					isColumn=1;
				}
				
				//ȥ���Ұ����Ļ�����ѯ
				else if((ChannelNum[1]=='.')||(ChannelNum[1]=='D')||(ChannelNum[2]=='.')||(ChannelNum[2]=='D')) 
				{
					columnState = 5;
					isColumn=1;
				}
				else
				{
					columnNo = GetColumnNum(ChannelNum,SystemPara.SubBinOpen);				
					columnState = ChannelCheckIsOk(columnNo%100,columnNo/100);
					if(SystemPara.PcEnable==UBOX_PC)//�ϱ�������Ϣ�����ػ�
					{
						ButtonRPTAPI(1,columnNo%100,columnNo/100);//�ϱ�pc������Ϣ
						channelInput = 0;
						memset(ChannelNum,0,sizeof(ChannelNum));
						if(GetAmountMoney() > 0)
						{				
							vmcStatus = VMC_SALE;
						}
						else
						{
							ClearDealPar(); 	
							CLrBusinessText();
							vmcStatus = VMC_FREE;
						}
						return;
					}
					//���ѱ�pcͨѶ
					else if(SystemPara.PcEnable==SIMPUBOX_PC)//�ϱ���������Ӧ����Ʒid��Ϣ�����ػ�
					{
						channel_id=hd_id_by_logic(columnNo/100,columnNo%100);
						if(channel_id)
						{
							if(hd_SIMPLEstate_by_id(columnNo/100,channel_id)!=1)
								ButtonSIMPLERPTAPI(channel_id);//�ϱ�pc������Ϣ
						}
						channelInput = 0;
						memset(ChannelNum,0,sizeof(ChannelNum));
						if(GetAmountMoney() > 0)
						{				
							vmcStatus = VMC_SALE;
						}
						else
						{
							ClearDealPar(); 	
							CLrBusinessText();
							vmcStatus = VMC_FREE;
						}
						return;
					}
					else
					{
						isColumn=1;
					}
				}
				
			}
		}
		//ֻ������
		else
		{
			if(channelInput >= 2)
			{
				//ȥ���Ұ����Ļ�����ѯ
				if((ChannelNum[0]=='.')||(ChannelNum[0]=='D')||(ChannelNum[1]=='.')||(ChannelNum[1]=='D'))	
				{
					columnState = 5;
					isColumn=1;
				}
				else
				{
					columnNo = GetColumnNum(ChannelNum,SystemPara.SubBinOpen);
					columnState = ChannelCheckIsOk(columnNo%100,columnNo/100);
					TracePC("\r\n APPUboxBtncloumn=%d",columnNo);
					if(SystemPara.PcEnable==UBOX_PC)//�ϱ�������Ϣ�����ػ�
					{
						ButtonRPTAPI(1,columnNo%100,columnNo/100);//�ϱ�pc������Ϣ
						channelInput = 0;
						memset(ChannelNum,0,sizeof(ChannelNum));
						if(GetAmountMoney() > 0)
						{				
							vmcStatus = VMC_SALE;
						}
						else
						{
							ClearDealPar(); 	
							CLrBusinessText();
							vmcStatus = VMC_FREE;
						}
						return;
					}
					//���ѱ�pcͨѶ
					else if(SystemPara.PcEnable==SIMPUBOX_PC)//�ϱ���������Ӧ����Ʒid��Ϣ�����ػ�
					{
						channel_id=hd_id_by_logic(columnNo/100,columnNo%100);
						//TracePC("\r\n 2APPUboxButton=%d",channel_id);
						if(channel_id)
						{
							if(hd_SIMPLEstate_by_id(columnNo/100,channel_id)!=1)//����û�н���
							{
								if(hd_get_by_id(columnNo/100,channel_id,3)!=3)
									ButtonSIMPLERPTAPI(channel_id);//�ϱ�pc������Ϣ
							}
						}
						channelInput = 0;
						memset(ChannelNum,0,sizeof(ChannelNum));
						if(GetAmountMoney() > 0)
						{				
							vmcStatus = VMC_SALE;
						}
						else
						{
							ClearDealPar(); 	
							CLrBusinessText();
							vmcStatus = VMC_FREE;
						}
						return;
					}
					else
					{
						isColumn=1;
					}
				}
				
			}
		}
	}
	//ʹ��ѡ������
	else if(*keyMode == 1)
	{
		//��ѡ�������õ�����ʹ�õĻ������
		columnNo = ChannelGetSelectColumn(1,1,*keyValue);
		//Trace("\r\n colu=%d",columnNo);
		if(columnNo == 0)
		{
			columnState = 2;
			isColumn=1;
		}
		//����һ��С���̣������ٰ�ѡ������
		else if(channelInput>0)
		{
			columnState = 5;
			isColumn=1;
		}
		else
		{
			//��ʾ�������	
			//��������
			if(SystemPara.SubBinOpen==1)
			{
				ChannelNum[channelInput++] = 'A';
				ChannelNum[channelInput++] = columnNo/10 + '0'; 
				ChannelNum[channelInput++] = columnNo%10 + '0';
			}
			else
			{
				ChannelNum[channelInput++] = columnNo/10 + '0'; 
				ChannelNum[channelInput++] = columnNo%10 + '0';
			}
			strcpy(strlanguage,BUSINESS[SystemPara.Language][0]); 
			strcat(strlanguage,ChannelNum);
			strcpy(streng,BUSINESS[1][0]);	
			strcat(streng,ChannelNum);	
			DispBusinessText(strlanguage,streng,"","");

			columnNo = GetColumnNum(ChannelNum,SystemPara.SubBinOpen);
			columnState = ChannelCheckIsOk(columnNo%100,columnNo/100);
			if(SystemPara.PcEnable==UBOX_PC)
			{
				ButtonRPTAPI(1,columnNo%100,columnNo/100);//�ϱ�pc������Ϣ
				channelInput = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				if(GetAmountMoney() > 0)
				{				
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar(); 	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				return;
			}
			//���ѱ�pcͨѶ
			else if(SystemPara.PcEnable==SIMPUBOX_PC)//�ϱ���������Ӧ����Ʒid��Ϣ�����ػ�
			{
				channel_id=hd_id_by_logic(columnNo/100,columnNo%100);
				if(channel_id)
				{
					ButtonSIMPLERPTAPI(channel_id);//�ϱ�pc������Ϣ
				}
				channelInput = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				if(GetAmountMoney() > 0)
				{				
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar(); 	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				return;
			}
			else
			{
				isColumn=1;
			}
		}		
	}
		
	if(isColumn)
	{	
		//Trace("\r\n chnum=%d,st=%d",GetColumnNum(ChannelNum),columnState);
		switch(columnState)
		{
			//ȱ��
			case 2:
			case 4:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][5]);
				strcpy(streng,BUSINESS[1][5]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{		
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar(); 
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;
			//����
			case 3:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][4]);
				strcpy(streng,BUSINESS[1][4]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{	
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar(); 
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;
			//�޴˻���	
			case 5:
			case 1:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][1]);
				strcpy(streng,BUSINESS[1][1]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{	
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar(); 
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;	
			//����	
			case 0: 								
				//strcpy(strlanguage,BUSINESS[SystemPara.Language][3]);
				//strcat(strlanguage,ChannelGetParamValue(GetColumnNum(ChannelNum),1,1));
				//strcpy(streng,BUSINESS[1][3]);	
				//Trace("\r\n money=%ld",GetAmountMoney());
				vmcPrice = ChannelGetParamValue(columnNo%100,1,columnNo/100);
				//Trace("vmcPrice=%d\r\n",vmcPrice);
				debtMoney = vmcPrice;
				switch(SystemPara.DecimalNum) 
				{
				  case 2://�Է�Ϊ��λ
					  sprintf(strlanguage,"%s %s,%s%02d.%02d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/100,debtMoney%100);
					  sprintf(streng,"%s %s,%s%02d.%02d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/100,debtMoney%100); 
					  break;

				  case 1://�Խ�Ϊ��λ
					  debtMoney /= 10;
					  sprintf(strlanguage,"%s %s,%s%d.%d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/10,debtMoney%10);
					  sprintf(streng,"%s %s,%s%d.%d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/10,debtMoney%10);
					  break;
				  
				  case 0://��ԪΪ��λ
					  sprintf(strlanguage,"%s %s,%s%d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/100);
					  sprintf(streng,"%s %s,%s%d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/100);
					  break;
				}	
				//strcpy(streng,BUSINESS[1][3]);
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC);
				if(GetAmountMoney() > 0)
				{
					vmcColumn = columnNo;
					vmcStatus = VMC_XUANHUO;
				}
				else
				{			
					OSTimeDly(OS_TICKS_PER_SEC);
					ClearDealPar(); 
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;	
		}
		//strcpy(strlanguage,BUSINESS[SystemPara.Language][3]);
		//strcpy(streng,BUSINESS[1][1]);	
		//DispBusinessText(strlanguage,streng,"","");
		//OSTimeDly(OS_TICKS_PER_SEC * 2);
		channelInput = 0;
		/*
		if(GetAmountMoney() > 0)
		{				
			vmcStatus = VMC_XUANHUO;
		}
		else
		{
			ClearDealPar(); 
			CLrBusinessText();
			vmcStatus = VMC_FREE;
		}*/
	}
	
	
}



/*********************************************************************************************************
** Function name:     	DispChaxunPage
** Descriptions:	    �����ѯ�з��������ҳ��
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChaxunHefangPage(uint8_t *keyValue)
{
	char strlanguage[30] = {0},streng[30] = {0};
	//char tempstrlanguage[30] = {0},tempstreng[30] = {0};	
	uint8_t columnState=0,isColumn=0,BinNo=0;
	uint16_t columnNo=0;
	uint32_t debtMoney=0;

	
	if(*keyValue == 'C')
	{
		channelInput = 0;
		channelMode = 0;
		memset(ChannelNum,0,sizeof(ChannelNum));
		memset(BinNum,0,sizeof(BinNum));
		if(GetAmountMoney() > 0)
		{				
			vmcStatus = VMC_SALE;
		}
		else
		{
			ClearDealPar();		
			CLrBusinessText();
			vmcStatus = VMC_FREE;
		}
		return;
	}
	
	//������ӱ��
	if(channelMode == 0)
	{
		if(*keyValue != 'E')
		{
			BinNum[channelInput++] = *keyValue;	
			strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][18]); 
			strcat(strlanguage,BinNum);		
			strcpy(streng,BUSINESSDEAL[1][18]);	
			strcat(streng,BinNum);	
			DispBusinessText(strlanguage,streng,"","");
		}
		//Trace("\r\n00keyvalue=%c,%s,%s",*keyValue,BinNum,ChannelNum);
		if(channelInput>=2)
		{
			if((BinNum[0]>='0')&&(BinNum[0]<='9')&&(BinNum[1]>='0')&&(BinNum[1]<='9'))
			{
				channelMode = 1;
				channelInput = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				strcpy(strlanguage,BinNum); 
				strcat(strlanguage,BUSINESSDEAL[SystemPara.Language][19]);		
				strcpy(streng,BinNum);	
				strcat(streng,BUSINESSDEAL[1][19]);	
				DispBusinessText(strlanguage,streng,"","");
			}
			else
			{
				channelInput = 0;
				channelMode = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				memset(BinNum,0,sizeof(BinNum));
				if(GetAmountMoney() > 0)
				{				
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();		
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				return;
			}
		}
		//��ǰ����ȷ�ϼ��Ĳ���
		else if(*keyValue == 'E')
		{
			//Trace("\r\n01keyvalue=%c,%s,%s",*keyValue,BinNum,ChannelNum);
			if((BinNum[0]>='0')&&(BinNum[0]<='9'))
			{
				BinNum[1]=BinNum[0];
				BinNum[0]='0';
				channelMode = 1;
				channelInput = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				sprintf(strlanguage,"%s%s",BinNum,BUSINESSDEAL[SystemPara.Language][19]);
				sprintf(streng,"%s%s",BinNum,BUSINESSDEAL[1][19]);
				DispBusinessText(strlanguage,streng,"","");
				//Trace("\r\n1keyvalue=%s,%s",BinNum,ChannelNum);
			}
			else
			{
				channelInput = 0;
				channelMode = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				memset(BinNum,0,sizeof(BinNum));
				if(GetAmountMoney() > 0)
				{				
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();		
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				return;
				//Trace("\r\n02keyvalue=%c,%s,%s",*keyValue,BinNum,ChannelNum);
			}
		}
	}
	//���뱾����ӱ��
	else if(channelMode == 1)
	{
		if(*keyValue != 'E')
		{
			ChannelNum[channelInput++] = *keyValue;	
			BinNo= (BinNum[0]-'0')*10+(BinNum[1]-'0');
			sprintf(strlanguage,"%d%s%s",BinNo,BUSINESSDEAL[SystemPara.Language][19],ChannelNum);
			sprintf(streng,"%d%s%s",BinNo,BUSINESSDEAL[1][19],ChannelNum);
			DispBusinessText(strlanguage,streng,"","");
		}
		//Trace("\r\n2keyvalue=%d,%s",BinNo,ChannelNum);//����Eʱ,BinNoû��ȥ����������Ϊ0
		if(channelInput>=2)
		{
			if((ChannelNum[0]>='0')&&(ChannelNum[0]<='9')&&(ChannelNum[1]>='0')&&(ChannelNum[1]<='9'))
			{
				columnNo = GetHefangNum(ChannelNum,BinNum);
				columnState = ChannelCheckIsOk(columnNo%100,columnNo/100);
				if(SystemPara.PcEnable==UBOX_PC)
				{
					ButtonRPTAPI(1,columnNo%100,columnNo/100);//�ϱ�pc������Ϣ
					channelInput = 0;
					channelMode = 0;
					memset(ChannelNum,0,sizeof(ChannelNum));
					memset(BinNum,0,sizeof(BinNum));
					if(GetAmountMoney() > 0)
					{				
						vmcStatus = VMC_SALE;
					}
					else
					{
						ClearDealPar();		
						CLrBusinessText();
						vmcStatus = VMC_FREE;
					}
					return;
				}
				else
				{
					isColumn=1;
				}
				//Trace("\r\ncolumn=%d",columnNo);
			}
			else
			{
				channelInput = 0;
				channelMode = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				memset(BinNum,0,sizeof(BinNum));
				if(GetAmountMoney() > 0)
				{				
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();		
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				return;
			}
		}
		else if(*keyValue == 'E')
		{
			//Trace("\r\n21keyvalue=%c,%s,%s",*keyValue,BinNum,ChannelNum);
			if((ChannelNum[0]>='0')&&(ChannelNum[0]<='9'))
			{
				ChannelNum[1]=ChannelNum[0];
				ChannelNum[0]='0';
				columnNo = GetHefangNum(ChannelNum,BinNum);
				columnState = ChannelCheckIsOk(columnNo%100,columnNo/100);
				if(SystemPara.PcEnable==UBOX_PC)
				{
					ButtonRPTAPI(1,columnNo%100,columnNo/100);//�ϱ�pc������Ϣ
					channelInput = 0;
					channelMode = 0;
					memset(ChannelNum,0,sizeof(ChannelNum));
					memset(BinNum,0,sizeof(BinNum));
					if(GetAmountMoney() > 0)
					{				
						vmcStatus = VMC_SALE;
					}
					else
					{
						ClearDealPar();		
						CLrBusinessText();
						vmcStatus = VMC_FREE;
					}
					return;
				}
				else
				{
					isColumn=1;
				}
				//Trace("\r\ncolumn=%d",columnNo);
			}
			else
			{
				channelInput = 0;
				memset(ChannelNum,0,sizeof(ChannelNum));
				sprintf(strlanguage,"%s%s",BinNum,BUSINESSDEAL[SystemPara.Language][19]);
				sprintf(streng,"%s%s",BinNum,BUSINESSDEAL[1][19]);
				DispBusinessText(strlanguage,streng,"","");
				return;
				//Trace("\r\n22keyvalue=%c,%s,%s",*keyValue,BinNum,ChannelNum);
			}
		}
	}

	if(isColumn)
	{	
		switch(columnState)
		{
			//ȱ��
			case 2:
			case 4:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][5]);
				strcpy(streng,BUSINESS[1][5]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{	
					channelInput = 0;
					channelMode = 0;
					memset(BinNum,0,sizeof(BinNum));
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;
			//����
			case 3:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][4]);
				strcpy(streng,BUSINESS[1][4]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{	
					channelInput = 0;
					channelMode = 0;
					memset(BinNum,0,sizeof(BinNum));
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;
			//�޴˻���	
			case 5:
            case 1:
				strcpy(strlanguage,BUSINESS[SystemPara.Language][1]);
				strcpy(streng,BUSINESS[1][1]);	
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC * 2);
				if(GetAmountMoney() > 0)
				{	
					channelInput = 0;
					channelMode = 0;
					memset(BinNum,0,sizeof(BinNum));
					memset(ChannelNum,0,sizeof(ChannelNum));
					vmcStatus = VMC_SALE;
				}
				else
				{
					ClearDealPar();	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;	
			//����	
			case 0:									
				vmcPrice = ChannelGetParamValue(columnNo%100,1,columnNo/100);
				//Trace("vmcPrice=%d\r\n",vmcPrice);
				debtMoney = vmcPrice;
				switch(SystemPara.DecimalNum) 
			    {
			      case 2://�Է�Ϊ��λ
				  	  sprintf(strlanguage,"%s %s,%s%02d.%02d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/100,debtMoney%100);
					  sprintf(streng,"%s %s,%s%02d.%02d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/100,debtMoney%100);	
					  break;

				  case 1://�Խ�Ϊ��λ
				  	  debtMoney /= 10;
					  sprintf(strlanguage,"%s %s,%s%d.%d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/10,debtMoney%10);
					  sprintf(streng,"%s %s,%s%d.%d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/10,debtMoney%10);
					  break;
				  
				  case 0://��ԪΪ��λ
					  sprintf(strlanguage,"%s %s,%s%d",BUSINESS[SystemPara.Language][7],ChannelNum,BUSINESS[SystemPara.Language][3],debtMoney/100);
					  sprintf(streng,"%s %s,%s%d",BUSINESS[1][7],ChannelNum,BUSINESS[1][3],debtMoney/100);
					  break;
			    }	
				//strcpy(streng,BUSINESS[1][3]);
				DispBusinessText(strlanguage,streng,"","");
				OSTimeDly(OS_TICKS_PER_SEC);
				if(GetAmountMoney() > 0)
				{
					vmcColumn = columnNo;
					vmcStatus = VMC_XUANHUO;
				}
				else
				{			
					OSTimeDly(OS_TICKS_PER_SEC);
					ClearDealPar();	
					CLrBusinessText();
					vmcStatus = VMC_FREE;
				}
				break;	
		}		
		channelInput = 0;
		channelMode = 0;
	}
	

}


/*********************************************************************************************************
** Function name:     	DispSalePage
** Descriptions:	    Ͷ�ҽ��н���ҳ��
** input parameters:    haveSale�Ƿ���й�һ�ν���
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispSalePage(uint8_t haveSale,uint8_t hefangMode)
{
	char strlanguage[30] = {0},streng[30] = {0};
	char rightstrlanguage[30] = {0},rightstreng[30] = {0};
	//char    *pstr;
	//char	strMoney[10];
	uint32_t dispnum;
	
	//LCDClrScreen();
	OSTimeDly(2);
	//g_Amount += moneyValue;
	//pstr = PrintfMoney(g_Amount);	
	//strcpy(strMoney, pstr);
	//Trace("\r\n2.coin=%s",strMoney);
	//Trace("\r\n money=%ld,%d,%ld,%ld",stDevValue.CoinDecimal,stDevValue.CoinScale,stDevValue.BillDecimal,stDevValue.BillScale);
	dispnum = GetAmountMoney();
	//Trace("\r\n 5money=%ld",dispnum);
	//��һ�ι���
	if(haveSale==0) 
	{
		//������ʾ
		if(SystemPara.Language != 1)
			LCDPrintf(76,LINE3,0,SystemPara.Language,"%s/%s",BUSINESSDEAL[SystemPara.Language][0],BUSINESSDEAL[1][0]);			
		else
			LCDPrintf(96,LINE3,0,SystemPara.Language,"%s",BUSINESSDEAL[1][0]);

		LCDClearLineDraw(0,LINE5,4);
		//���
		if(SystemPara.Language == 0)
			LCDSpecialPicPrintf(44,LINE6,0,2);//������		
		switch(SystemPara.DecimalNum) 
	    {
	      case 2://�Է�Ϊ��λ
		  	  //sprintf(strnum,"%02d.%02d",dispnum/100,dispnum%100);	
			  LCDNumberFontPrintf(76,LINE5,4,"%02d.%02d",dispnum/100,dispnum%100);	
			  break;

		  case 1://�Խ�Ϊ��λ
		  	  dispnum /= 10;
			  //sprintf(strnum,"%d.%d",dispnum/10,dispnum%10);
			  LCDNumberFontPrintf(76,LINE5,4,"%d.%d",dispnum/10,dispnum%10);	
			  break;
		  
		  case 0://��ԪΪ��λ
			  //sprintf(strnum,"%d",dispnum/100);
			  LCDNumberFontPrintf(76,LINE5,4,"%d",dispnum/100);	
			  break;
	    }	/**/		
		//������ʾ
		//�з���������ʾ
		if(hefangMode==1)
		{
			strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][18]); 
			strcpy(streng,BUSINESSDEAL[1][18]);	
		}
		//��ͨ����������ʾ
		else
		{
			strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][4]); 
			strcpy(streng,BUSINESSDEAL[1][4]);	
		}
		DispBusinessText(strlanguage,streng,"","");
	}
	//��������
	else
	{
		//������ʾ
		if(SystemPara.Language != 1)
			LCDPrintf(76,LINE3,0,SystemPara.Language,"%s/%s",BUSINESSDEAL[SystemPara.Language][1],BUSINESSDEAL[1][1]);			
		else
			LCDPrintf(96,LINE3,0,SystemPara.Language,"%s",BUSINESSDEAL[SystemPara.Language][1]);
		//Trace("\r\n 3money=%ld",dispnum);
		LCDClearLineDraw(0,LINE5,4);
		//���
		if(SystemPara.Language == 0)
			LCDSpecialPicPrintf(44,LINE6,0,2);//������
		switch(SystemPara.DecimalNum) 
	    {
	      case 2://�Է�Ϊ��λ
		  	  //sprintf(strnum,"%02d.%02d",dispnum/100,dispnum%100);	
			  LCDNumberFontPrintf(76,LINE5,4,"%02d.%02d",dispnum/100,dispnum%100);	
			  break;

		  case 1://�Խ�Ϊ��λ
		  	  dispnum /= 10;
			  //sprintf(strnum,"%d.%d",dispnum/10,dispnum%10);
			  LCDNumberFontPrintf(76,LINE5,4,"%d.%d",dispnum/10,dispnum%10);	
			  break;
		  
		  case 0://��ԪΪ��λ
			  //sprintf(strnum,"%d",dispnum/100);
			  LCDNumberFontPrintf(76,LINE5,4,"%d",dispnum/100);	
			  break;
	    }		
		//������ʾ
		//�з���������ʾ
		if(hefangMode==1)
		{
			strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][18]); 
			strcpy(streng,BUSINESSDEAL[1][18]);	
		}
		//��ͨ����������ʾ
		else
		{
			strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][5]); 
			strcpy(streng,BUSINESSDEAL[1][5]);	
			strcpy(rightstrlanguage,BUSINESSDEAL[SystemPara.Language][6]); 
			strcpy(rightstreng,BUSINESSDEAL[1][6]);
		}
		DispBusinessText(strlanguage,streng,rightstrlanguage,rightstreng);
	}
}

/*********************************************************************************************************
** Function name:     	DispOverAmountPage
** Descriptions:	    Ͷ��ֽ�ҳ����������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispOverAmountPage()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][2]); 
	strcpy(streng,BUSINESSDEAL[1][2]);		
	DispBusinessText(strlanguage,streng,"","");
	//OSTimeDly(OS_TICKS_PER_SEC*2);
}

/*********************************************************************************************************
** Function name:     	DispCannotBuyPage
** Descriptions:	    �޷�������Ϊ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispCannotBuyPage(uint32_t PriceSale)
{
	char strlanguage[30] = {0},streng[30] = {0},strlanguage2[30] = {0};
	
	
	strcpy(strlanguage2,BUSINESSDEAL[SystemPara.Language][3]); 
	strcpy(streng,BUSINESSDEAL[1][3]);	
	switch(SystemPara.DecimalNum) 
    {
      case 2://�Է�Ϊ��λ
	  	  sprintf(strlanguage,"%02d.%02d",PriceSale/100,PriceSale%100);
		  //LCDNumberFontPrintf(51,LINE5,4,"%02d.%02d",debtMoney/100,debtMoney%100);	
		  break;

	  case 1://�Խ�Ϊ��λ
	  	  PriceSale /= 10;
		  //LCDNumberFontPrintf(51,LINE5,4,"%d.%d",debtMoney/10,debtMoney%10);	
		  sprintf(strlanguage,"%d.%d",PriceSale/10,PriceSale%10);
		  break;
	  
	  case 0://��ԪΪ��λ
		  //LCDNumberFontPrintf(51,LINE5,4,"%d",debtMoney/100);	
		  sprintf(strlanguage,"%d",PriceSale/100);
		  break;
    }	
	strcat(strlanguage2,strlanguage);
	DispBusinessText(strlanguage2,streng,"","");
	OSTimeDly(OS_TICKS_PER_SEC * 2);
}

/*********************************************************************************************************
** Function name:     	DispCannotBuyPage
** Descriptions:	    �޷�������Ϊ��������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispCannotBuyAsPayoutPage()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][14]); 
	strcpy(streng,BUSINESSDEAL[1][14]);		
	DispBusinessText(strlanguage,streng,"","");
	OSTimeDly(OS_TICKS_PER_SEC * 2);
}

/*********************************************************************************************************
** Function name:     	DispReaderDevVendoutRPT
** Descriptions:	    ���������ڿۿ���Ժ�
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispReaderDevVendoutRPT()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][15]); 
	strcpy(streng,BUSINESSDEAL[1][15]);		
	DispBusinessText(strlanguage,streng,"","");
	OSTimeDly(OS_TICKS_PER_SEC / 10);
}

/*********************************************************************************************************
** Function name:     	DispReaderVendoutFail
** Descriptions:	    �������ۿ�ʧ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispReaderVendoutFail()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][16]); 
	strcpy(streng,BUSINESSDEAL[1][16]);		
	DispBusinessText(strlanguage,streng,"","");
	OSTimeDly(OS_TICKS_PER_SEC * 2);
}



/*********************************************************************************************************
** Function name:     	DispChuhuoPage
** Descriptions:	    ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChuhuoPage()
{
	char strlanguage[30] = {0},streng[30] = {0};

	sprintf(strlanguage,"%d %s",vmcColumn%100,BUSINESSDEAL[SystemPara.Language][11]);
	sprintf(streng,"%d %s",vmcColumn%100,BUSINESSDEAL[1][11]);
	//strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][11]); 
	//strcpy(streng,BUSINESSDEAL[1][11]);		
	DispBusinessText(strlanguage,streng,"","");	
	//OSTimeDly(OS_TICKS_PER_SEC / 5);
}


/*********************************************************************************************************
** Function name:     	DispChuhuoPagePC
** Descriptions:	    PCָʾ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChuhuoPagePC()
{
	char strlanguage[30] = {0},streng[30] = {0};

	sprintf(strlanguage,"%s",BUSINESSDEAL[SystemPara.Language][11]);
	sprintf(streng,"%s",BUSINESSDEAL[1][11]);
	//strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][11]); 
	//strcpy(streng,BUSINESSDEAL[1][11]);		
	DispBusinessText(strlanguage,streng,"","");	
	//OSTimeDly(OS_TICKS_PER_SEC / 2);
}


/*********************************************************************************************************
** Function name:     	DispQuhuoPage
** Descriptions:	    ȡ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispQuhuoPage()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][12]); 
	strcpy(streng,BUSINESSDEAL[1][12]);		
	DispBusinessText(strlanguage,streng,"","");	
	OSTimeDly(OS_TICKS_PER_SEC / 2);
}

/*********************************************************************************************************
** Function name:     	DispChhuoFailPage
** Descriptions:	    ����ʧ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispChhuoFailPage()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSDEAL[SystemPara.Language][13]); 
	strcpy(streng,BUSINESSDEAL[1][13]);		
	DispBusinessText(strlanguage,streng,"","");	
	OSTimeDly(OS_TICKS_PER_SEC * 2);
}

/*********************************************************************************************************
** Function name:     	DispPayoutPage
** Descriptions:	    ��������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispPayoutPage()
{
	char strlanguage[30] = {0},streng[30] = {0};

	//LCDClrScreen();
	/*
	switch(SystemPara.DecimalNum) 
    {
      case 2://�Է�Ϊ��λ
	  	  //sprintf(strnum,"%02d.%02d",dispnum/100,dispnum%100);	
		  LCDNumberFontPrintf(76,LINE5,4,"%02d.%02d",0/100,0%100);	
		  break;

	  case 1://�Խ�Ϊ��λ
	  	  //sprintf(strnum,"%d.%d",dispnum/10,dispnum%10);
		  LCDNumberFontPrintf(76,LINE5,4,"%d.%d",0/10,0%10);	
		  break;
	  
	  case 0://��ԪΪ��λ
		  //sprintf(strnum,"%d",dispnum/100);
		  LCDNumberFontPrintf(76,LINE5,4,"%d",0/100);	
		  break;
    }*/	
	strcpy(strlanguage,BUSINESSCHANGE[SystemPara.Language][0]); 
	strcpy(streng,BUSINESSCHANGE[1][0]);		
	DispBusinessText(strlanguage,streng,"","");	
	//OSTimeDly(OS_TICKS_PER_SEC * 2);
}

/*********************************************************************************************************
** Function name:     	DispQuChangePage
** Descriptions:	    ȡ��Ǯ
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispQuChangePage()
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	strcpy(strlanguage,BUSINESSCHANGE[SystemPara.Language][2]); 
	strcpy(streng,BUSINESSCHANGE[1][2]);		
	DispBusinessText(strlanguage,streng,"","");	
	OSTimeDly(OS_TICKS_PER_SEC / 2);
}

/*********************************************************************************************************
** Function name:     	DispIOUPage
** Descriptions:	    ����ʧ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispIOUPage(uint32_t debtMoney)
{
	char strlanguage[30] = {0},streng[30] = {0};
	
	switch(SystemPara.DecimalNum) 
    {
      case 2://�Է�Ϊ��λ
	  	  sprintf(strlanguage,"%s%02d.%02d",BUSINESSCHANGE[SystemPara.Language][1],debtMoney/100,debtMoney%100);
		  //LCDNumberFontPrintf(51,LINE5,4,"%02d.%02d",debtMoney/100,debtMoney%100);	
		  break;

	  case 1://�Խ�Ϊ��λ
	  	  debtMoney /= 10;
		  //LCDNumberFontPrintf(51,LINE5,4,"%d.%d",debtMoney/10,debtMoney%10);	
		  sprintf(strlanguage,"%s%d.%d",BUSINESSCHANGE[SystemPara.Language][1],debtMoney/10,debtMoney%10);
		  break;
	  
	  case 0://��ԪΪ��λ
		  //LCDNumberFontPrintf(51,LINE5,4,"%d",debtMoney/100);	
		  sprintf(strlanguage,"%s%d",BUSINESSCHANGE[SystemPara.Language][1],debtMoney/100);
		  break;
    }	
	strcpy(streng,BUSINESSCHANGE[1][1]);	
	//sprintf(streng,"%ld",debtMoney);
	DispBusinessText(strlanguage,streng,"","");	
	OSTimeDly(OS_TICKS_PER_SEC * 5);
}

/*********************************************************************************************************
** Function name:     	DispEndPage
** Descriptions:	    ���׽���
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispEndPage()
{
	char strlanguage[30] = {0};
	LCDClrScreen();
	OSTimeDly(2);
	//LCDPutLOGOBmp(75,LINE1,SystemPara.Logo);
	strcpy(strlanguage,BUSINESSCHANGE[1][3]); 
	LCDNumberFontPrintf(48,LINE6,3,strlanguage);
	if(SystemPara.Language != 1)
	{
		//strcpy(strlanguage,BUSINESSCHANGE[SystemPara.Language][3]);
		//LCDPrintf(32,LINE7,0,SystemPara.Language,strlanguage);
		strcpy(strlanguage,BUSINESSCHANGE[SystemPara.Language][4]);
		LCDPrintf(60,LINE12,0,SystemPara.Language,strlanguage);
	}	
	//OSTimeDly(OS_TICKS_PER_SEC * 2);
}

/*********************************************************************************************************
** Function name:     	GetAmountMoney
** Descriptions:	    Ͷ���ܽ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint32_t GetAmountMoney()
{	
	return g_coinAmount + g_billAmount + g_holdValue + g_readerAmount;
}

/*********************************************************************************************************
** Function name:     	GetReaderAmount
** Descriptions:	    ˢ���ܽ���ܽ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint32_t GetReaderAmount()
{	
	return g_readerAmount;
}



/*********************************************************************************************************
** Function name:       UpdateErrBill
** Descriptions:        ����ֽ�����ձҺ󣬲���ʾ���ʱ���Զ������˱Һ͸�λ
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void UpdateErrBill(void)
{		
	if( (GetAmountMoney()==0)&&(vmcChangeLow==0)&&(DeviceStateBusiness.Billdisable==1) )
	{
		TraceBill("\r\n ErrBill=%d,%d,%d",GetAmountMoney(),vmcChangeLow,DeviceStateBusiness.Billdisable);
		ReturnBillDevMoneyInAPI();
		OSTimeDly(OS_TICKS_PER_SEC / 10);
		BillCoinCtr(1,0,0);	
		OSTimeDly(OS_TICKS_PER_SEC / 10);
	}
}

/*********************************************************************************************************
** Function name:     	rstTime
** Descriptions:	    ��Ļ��ʾʱ��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void rstTime()
{
	vmRTC.year = 0;
	vmRTC.month =0;
	vmRTC.day =0;
	vmRTC.hour = 0;
	vmRTC.minute =0;
	Timer.DispFreeTimer=1;
}

//�����Ƿ����ֽ��豸1,����,2�ر�
void BillCoinEnable(uint8_t enable)
{	
	uint8_t billCtr=0,coinCtr=0,readerCtr=0;
	//����
	if(enable==1)
	{
		//ֽ����
		if((GetBillCoinStatus(1)==0)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
		{
			billCtr=1;
			vmcChangeLow = 0;
			LCDClrScreen();
			rstTime();			
		}
		//Ӳ����
		if((GetBillCoinStatus(2)==0)
			&&((SystemPara.CoinAcceptorType == PARALLEL_COINACCEPTER)||(SystemPara.CoinAcceptorType == SERIAL_COINACCEPTER))			
		)
		{
			coinCtr=1;
		}
	}
	//�ر�
	else if(enable==2)
	{
		//ֽ����
		if((GetBillCoinStatus(1)==1)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
		{
			billCtr=2;
			vmcChangeLow = 1;
			LCDClrScreen();
			rstTime();
		}
		//Ӳ����
		if((GetBillCoinStatus(2)==1)
			&&((SystemPara.CoinAcceptorType == PARALLEL_COINACCEPTER)||(SystemPara.CoinAcceptorType == SERIAL_COINACCEPTER))
			&&(SystemPara.HpEmpCoin!=1)
		)
		{
			coinCtr=2;
		}
	}

	BillCoinCtr(billCtr,coinCtr,readerCtr); 
	//����ֽ��������֮����Ҫ�ϱ��豸״̬
	if(billCtr>0)
	{
		StatusRPTAPI();
	}
}

/*********************************************************************************************************
** Function name:     	UnpdateTubeMoney
** Descriptions:	    ���¿�������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint8_t UnpdateTubeMoney()
{
	uint32_t coinMoney=0,billMoney=0;	
	uint8_t i,j=0;
	//ChangeGetTubesAPI();
	//OSTimeDly(OS_TICKS_PER_SEC / 10);
	//1.����ֽ��ѭ�������
	if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
	{
		for(i=0;i<7;i++)
		{
			if(stDevValue.RecyclerValue[i])
			{
				billMoney = billMoney + stDevValue.RecyclerValue[i]*stDevValue.RecyclerNum[i];
				j=i;
			}
		}
	}
	//2.����Ӳ�Ҵ�Ҷ����
	if(SystemPara.CoinChangerType == MDB_CHANGER)
	{
		coinMoney = stDevValue.CoinValue[0]*stDevValue.CoinNum[0] + stDevValue.CoinValue[1]*stDevValue.CoinNum[1] + stDevValue.CoinValue[2]*stDevValue.CoinNum[2]
					+stDevValue.CoinValue[3]*stDevValue.CoinNum[3] + stDevValue.CoinValue[4]*stDevValue.CoinNum[4] + stDevValue.CoinValue[5]*stDevValue.CoinNum[5]
					+stDevValue.CoinValue[6]*stDevValue.CoinNum[6] + stDevValue.CoinValue[7]*stDevValue.CoinNum[7]
					+stDevValue.CoinValue[8]*stDevValue.CoinNum[8] + stDevValue.CoinValue[9]*stDevValue.CoinNum[9] + stDevValue.CoinValue[10]*stDevValue.CoinNum[10]
					+stDevValue.CoinValue[11]*stDevValue.CoinNum[11] + stDevValue.CoinValue[12]*stDevValue.CoinNum[12] + stDevValue.CoinValue[13]*stDevValue.CoinNum[13]
					+stDevValue.CoinValue[14]*stDevValue.CoinNum[14] + stDevValue.CoinValue[15]*stDevValue.CoinNum[15]; 
	}
	else if(SystemPara.CoinChangerType == HOPPER_CHANGER)
	{		
		coinMoney =( !HopperIsEmpty() )? SystemPara.MaxValue:0;
	}
	else if(SystemPara.CoinChangerType == OFF_CHANGER)
	{
		coinMoney = 0;
	}
	//3.�������Ͷ������
	MoneyMaxin =( (billMoney + coinMoney) > SystemPara.MaxValue )? SystemPara.MaxValue:(billMoney + coinMoney);
	TraceBill("\r\nAppChange 5=%ld,1=%ld,rec=%ld,bill=%ld,coin=%ld,max=%ld,money=%ld,enable=%ld",stDevValue.CoinValue[0]*stDevValue.CoinNum[0],stDevValue.CoinValue[1]*stDevValue.CoinNum[1],stDevValue.RecyclerValue[j]*stDevValue.RecyclerNum[j],
		billMoney,coinMoney,SystemPara.MaxValue,MoneyMaxin,SystemPara.BillEnableValue);

	//4.�Ƿ�����ֽ��豸
	if(SystemPara.CoinChangerType == MDB_CHANGER)
	{
		if(coinMoney < SystemPara.BillEnableValue)
		{
			BillCoinEnable(2);
		}
		else
		{
			BillCoinEnable(1);
		}
	}	
	else if(SystemPara.CoinChangerType == HOPPER_CHANGER)
	{		
		if(coinMoney < SystemPara.BillEnableValue)
		{
			BillCoinEnable(2);
		}
		else
		{
			BillCoinEnable(1);
		}
	}
	else if(SystemPara.CoinChangerType == OFF_CHANGER)
	{
		//����ֽ��ѭ�������
		if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
		{
			if((billMoney + coinMoney) < SystemPara.BillEnableValue)
			{
				BillCoinEnable(2);
			}
			else
			{
				BillCoinEnable(1);
			}
		}		
		else
		{
			MoneyMaxin =SystemPara.MaxValue;
			TraceBill("\r\nAppChange max=%ld",PriceMaxin);
		}
	}
	//����ֽ�����ձҺ󣬲���ʾ���ʱ���Զ������˱Һ͸�λ
	UpdateErrBill();
	return 0;
}
/*
uint8_t UnpdateTubeMoney()
{
	uint32_t coinMoney=0;	
	uint8_t i,j=0;
	//ChangeGetTubesAPI();
	//OSTimeDly(OS_TICKS_PER_SEC / 10);
	if(SystemPara.CoinChangerType == MDB_CHANGER)
	{
		coinMoney = stDevValue.CoinValue[0]*stDevValue.CoinNum[0] + stDevValue.CoinValue[1]*stDevValue.CoinNum[1] + stDevValue.CoinValue[2]*stDevValue.CoinNum[2]
					+stDevValue.CoinValue[3]*stDevValue.CoinNum[3] + stDevValue.CoinValue[4]*stDevValue.CoinNum[4] + stDevValue.CoinValue[5]*stDevValue.CoinNum[5]
					+stDevValue.CoinValue[6]*stDevValue.CoinNum[6] + stDevValue.CoinValue[7]*stDevValue.CoinNum[7]
					+stDevValue.CoinValue[8]*stDevValue.CoinNum[8] + stDevValue.CoinValue[9]*stDevValue.CoinNum[9] + stDevValue.CoinValue[10]*stDevValue.CoinNum[10]
					+stDevValue.CoinValue[11]*stDevValue.CoinNum[11] + stDevValue.CoinValue[12]*stDevValue.CoinNum[12] + stDevValue.CoinValue[13]*stDevValue.CoinNum[13]
					+stDevValue.CoinValue[14]*stDevValue.CoinNum[14] + stDevValue.CoinValue[15]*stDevValue.CoinNum[15]; 
		//����ֽ��ѭ�������
		if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
		{
			for(i=0;i<7;i++)
			{
				if(stDevValue.RecyclerValue[i])
				{
					coinMoney = coinMoney + stDevValue.RecyclerValue[i]*stDevValue.RecyclerNum[i];
					j=i;
				}
			}
		}
		MoneyMaxin =( coinMoney > SystemPara.MaxValue )? SystemPara.MaxValue:coinMoney;
		TraceBill("\r\nAppChange 5=%ld,1=%ld,rec=%ld,money=%ld,max=%ld,bill=%ld",stDevValue.CoinValue[0]*stDevValue.CoinNum[0],stDevValue.CoinValue[1]*stDevValue.CoinNum[1],stDevValue.RecyclerValue[j]*stDevValue.RecyclerNum[j],coinMoney,MoneyMaxin,SystemPara.BillEnableValue);
		if(MoneyMaxin < SystemPara.BillEnableValue)
		{
			if((GetBillCoinStatus(1)==1)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
			{
				BillCoinCtr(2,0,0);	
				vmcChangeLow = 1;
				LCDClrScreen();
				rstTime();
			}
		}
		else
		{
			if((GetBillCoinStatus(1)==0)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
			{
				BillCoinCtr(1,0,0);	
				vmcChangeLow = 0;
				LCDClrScreen();
				rstTime();
			}
		}
	}	
	else if(SystemPara.CoinChangerType == HOPPER_CHANGER)
	{		
		coinMoney =( !HopperIsEmpty() )? SystemPara.MaxValue:0;
		TraceBill("\r\nAppChange coinMoney=%ld",coinMoney);
		//����ֽ��ѭ�������
		if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
		{
			for(i=0;i<7;i++)
			{
				if(stDevValue.RecyclerValue[i])
				{
					coinMoney = coinMoney + stDevValue.RecyclerValue[i]*stDevValue.RecyclerNum[i];
					j=i;
				}
			}
		}
		MoneyMaxin =( coinMoney > SystemPara.MaxValue )? SystemPara.MaxValue:coinMoney;
		TraceBill("\r\nAppChange 5=%ld,1=%ld,rec=%ld,money=%ld,max=%ld,bill=%ld",stDevValue.CoinValue[0]*stDevValue.CoinNum[0],stDevValue.CoinValue[1]*stDevValue.CoinNum[1],stDevValue.RecyclerValue[j]*stDevValue.RecyclerNum[j],coinMoney,MoneyMaxin,SystemPara.BillEnableValue);
		if(MoneyMaxin < SystemPara.BillEnableValue)
		{
			if((GetBillCoinStatus(1)==1)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
			{
				BillCoinCtr(2,0,0);	
				vmcChangeLow = 1;
				LCDClrScreen();
				rstTime();
			}
		}
		else
		{
			if((GetBillCoinStatus(1)==0)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
			{
				BillCoinCtr(1,0,0);	
				vmcChangeLow = 0;
				LCDClrScreen();
				rstTime();
			}
		}
	}
	else if(SystemPara.CoinChangerType == OFF_CHANGER)
	{
		//����ֽ��ѭ�������
		if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
		{
			for(i=0;i<7;i++)
			{
				if(stDevValue.RecyclerValue[i])
				{
					coinMoney = coinMoney + stDevValue.RecyclerValue[i]*stDevValue.RecyclerNum[i];
					j=i;
				}
			}
			MoneyMaxin =( coinMoney > SystemPara.MaxValue )? SystemPara.MaxValue:coinMoney;
			TraceBill("\r\nAppChange rec=%ld,coinMoney=%ld,max=%ld,bill=%ld",stDevValue.RecyclerValue[j]*stDevValue.RecyclerNum[j],coinMoney,MoneyMaxin,SystemPara.BillEnableValue);
			if(MoneyMaxin < SystemPara.BillEnableValue)
			{
				if((GetBillCoinStatus(1)==1)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
				{
					BillCoinCtr(2,0,0);	
					vmcChangeLow = 1;
					LCDClrScreen();
					rstTime();
				}
			}
			else
			{
				if((GetBillCoinStatus(1)==0)&&(SystemPara.BillValidatorType != OFF_BILLACCEPTER))
				{
					BillCoinCtr(1,0,0);	
					vmcChangeLow = 0;
					LCDClrScreen();
					rstTime();
				}
			}
		}		
		else
		{
			MoneyMaxin =SystemPara.MaxValue;
			TraceBill("\r\nAppChange max=%ld",PriceMaxin);
		}
	}
	//����ֽ�����ձҺ󣬲���ʾ���ʱ���Զ������˱Һ͸�λ
	UpdateErrBill();
	return 0;
}
*/



/*********************************************************************************************************
** Function name:     	GetMoney
** Descriptions:	    �õ����׽��
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint8_t GetMoney()
{
	uint32_t InValue;	
	static uint8_t readerType = 0;
	
	//1.Ӳ����ѯ
	if(SystemPara.CoinAcceptorType != OFF_COINACCEPTER)
	{
		InValue=GetCoinDevMoneyInAPI();
		if(InValue>0)
		{			
			g_coinAmount += InValue;
			/*
			if(GetAmountMoney() >= 5000)
			{
				if(g_holdValue > 0)
					BillCoinCtr(0,2,2);
				else
					BillCoinCtr(2,2,2);	
			}
			else
			*/
			TraceCoin("\r\nAppcoin1.coin=%ld,%ld",InValue,GetAmountMoney());
			{
				BillCoinCtr(0,0,2);	
			}			
			LogGetMoneyAPI(InValue,1);//��¼��־
			PayinRPTAPI(1,InValue,GetAmountMoney());//�ϱ�PC��
			return 1;		
		}
	}
	//2.ֽ����ѯ
	if(SystemPara.BillValidatorType != OFF_BILLACCEPTER)
	{
		InValue=GetBillDevMoneyUnStackInAPI();
		if(InValue>0)
		{
			TraceBill("\r\n2.Appbill=%ld",InValue);
			TraceBill("\r\nAppbill=%ld,Money=%ld,price=%ld\r\n",(g_billAmount + InValue),MoneyMaxin,PriceMaxin);
			if( ((g_billAmount + InValue) < MoneyMaxin) )
			{
				if(StackedBillDevMoneyInAPI())
				{
					g_billAmount += InValue;
					LogGetMoneyAPI(InValue,2);//��¼��־
					PayinRPTAPI(2,InValue,GetAmountMoney());//�ϱ�PC��
					InValue = 0;
				}
				else
				{
					ReturnBillDevMoneyInAPI();
					return 0;
				}
			}
			else
			{
				if(SystemPara.BillITLValidator == ITL_BILLACCEPTER)
				{
					DispOverAmountPage();					
					if(GetAmountMoney())
					{
						OSTimeDly(350);
						Timer.SaleTimer = SaleTimeSet(0);
						vmcStatus = VMC_SALE;
						channelInput = 0;
						channelMode = 0;
						memset(BinNum,0,sizeof(BinNum));
						memset(ChannelNum,0,sizeof(ChannelNum));
						OSMboxAccept(g_CoinMoneyBackMail);
						vmcPrice = 0;
						DispSalePage(0,hefangMode);
						ReturnBillDevMoneyInAPI();	
					}
					else
					{
						ClearDealPar();	
						vmcStatus = VMC_FREE;
						ReturnBillDevMoneyInAPI();	
						OSTimeDly(OS_TICKS_PER_SEC*2);
						CLrBusinessText();
						rstTime();
					}
					g_holdValue = 0;
					return 0;
				}
				else
				{
					g_holdValue = InValue;
					PayinRPTAPI(3,InValue,GetAmountMoney());//�ϱ�PC��
					InValue = 0;
				}
			}
			if((g_billAmount + InValue) >= MoneyMaxin)
				BillCoinCtr(2,0,2);	
			else
				BillCoinCtr(0,0,2);		
			return 1;
		}
	}

	//3.��������ѯ
	if(SystemPara.CashlessDeviceType != OFF_READERACCEPTER)
	{
		InValue = GetReaderDevMoneyInAPI(&readerType);
		if( (readerType == 1)&&(InValue > 0) )
		{
			TraceReader("\r\n AppReader1.read=%ld",InValue);
			g_readerAmount = InValue;
			LogGetMoneyAPI(InValue,3);//��¼��־
			BillCoinCtr(2,2,0);
			PayinRPTAPI(5,InValue,GetAmountMoney());//�ϱ�PC��
			return 1;		
		}
		else if(readerType == 2)
		{		
			TraceReader("\r\n AppReader OUTPUT card");
			PayoutRPTAPI(2,0,GetAmountMoney(),0);
			readerType = 0;
			g_readerAmount = 0;
			return 2;
		}
	}
	
	return 0;
}

/*********************************************************************************************************
** Function name:       ChangerRecycler
** Descriptions:        ֽ��ѭ������������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void ChangerRecycler(void)
{
	uint8_t i,num,status;
	uint32_t paymoney=0;
	uint32_t  RecyPayoutMoneyBack=0;
	if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
	{
		paymoney=GetAmountMoney();
		if(paymoney)
		{
			TraceBill("\r\n AppNeedpay=%ld",paymoney);
			for(i=0;i<7;i++)
			{
				if(stDevValue.RecyclerValue[i])
				{
					num=paymoney/stDevValue.RecyclerValue[i];
					TraceBill("\r\n AppNeednum=%d",num);
					num=(stDevValue.RecyclerNum[i]>=num)?num:stDevValue.RecyclerNum[i];
					TraceBill("\r\n AppRealnum=%d",num);
					status=BillRecyclerPayoutValueExpanseAPI(stDevValue.RecyclerValue[i]*num,&RecyPayoutMoneyBack);
					TraceBill("\r\n AppRecback st=%d,pay=%ld",status,RecyPayoutMoneyBack);
					if(status==1)
					{
						paymoney = (g_coinAmount + g_billAmount)-RecyPayoutMoneyBack;
						g_billAmount=0;
						g_coinAmount = paymoney;
						TraceBill("\r\n Apppay=%ld",paymoney);
						if(SystemPara.EasiveEnable == 1)
						{
							PayoutRPTAPI(1,0,RecyPayoutMoneyBack,paymoney);
						}
					}
					break;
				}
			}
		}
	}
	else if(SystemPara.BillRecyclerType==FS_BILLRECYCLER)
	{
		paymoney=GetAmountMoney();
		if(paymoney)
		{
			print_fs("\r\n AppNeedpay=%ld",paymoney);				
			num=paymoney/SystemPara.RecyclerMoney;
			print_fs("\r\n AppNeednum=%d",num);
			num=(stDevValue.RecyclerNum[0]>=num)?num:stDevValue.RecyclerNum[0];
			print_fs("\r\n AppRealnum=%d",num);
			status=BillRecyclerPayoutValueExpanseAPI(SystemPara.RecyclerMoney*num,&RecyPayoutMoneyBack);
			print_fs("\r\n AppRecback st=%d,pay=%ld",status,RecyPayoutMoneyBack);
			if(status==1)
			{
				paymoney = (g_coinAmount + g_billAmount)-RecyPayoutMoneyBack;
				g_billAmount=0;
				g_coinAmount = paymoney;
				print_fs("\r\n Apppay=%ld",paymoney);
				if(SystemPara.EasiveEnable == 1)
				{
					PayoutRPTAPI(1,0,RecyPayoutMoneyBack,paymoney);
				}
			}				
			
		}
	}
}

/*********************************************************************************************************
** Function name:       ChangerMoney
** Descriptions:        ����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint32_t ChangerMoney(void)
{	
	uint32_t backmoney;
	unsigned char ComStatus;
	uint32_t tempmoney;//�������ѱ��ϱ�ֽ�Һ�Ӳ��������֮�ܺ͵�

	//�ݴ��˱�
	if(g_holdValue)
	{
		if(ReturnBillDevMoneyInAPI())
		{
			PayinRPTAPI(4,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
			g_holdValue = 0;			
		}
		TracePC("\r\n AppHoldRet%d",OSTimeGet());
		OSTimeDly(OS_TICKS_PER_SEC/2);
	}
	tempmoney=GetAmountMoney();//�������ѱ��ϱ�ֽ�Һ�Ӳ��������֮�ܺ͵�
	//ֽ��ѭ��������
	ChangerRecycler();
	//����Ӳ��
	if(GetAmountMoney())
	{
		TracePC("\r\n AppBegin change%d",OSTimeGet());
		//OSTimeDly(OS_TICKS_PER_SEC*2);
		//ActionRPTAPI(2,0,30,0,0,GetAmountMoney(),GetAmountMoney());
		//OSTimeDly(OS_TICKS_PER_SEC/2);
		ComStatus = ChangerDevPayoutAPI(GetAmountMoney(),&backmoney);		
	}
	else
	{
		ComStatus = 1;
	}

	if(SystemPara.EasiveEnable == 1)
	{
		//����ʧ��
		if(!ComStatus)
		{		
			TracePC("\r\n Appchange Fail=%ld,%ld",GetAmountMoney(),backmoney);
			LogChangeAPI(GetAmountMoney()-backmoney,backmoney);//��¼��־
			PayoutRPTAPI(0,0,GetAmountMoney()-backmoney,0);
			//OSTimeDly(OS_TICKS_PER_SEC);
			//PayinRPTAPI(2,0,0);//�ϱ�PC��
			g_coinAmount = 0;
			g_billAmount = 0;
			return  backmoney;
		}
		//����ɹ�
		else
		{
			TracePC("\r\n Appchange succ=%ld",GetAmountMoney());
			LogChangeAPI(GetAmountMoney(),0);//��¼��־
			PayoutRPTAPI(0,0,GetAmountMoney(),0);
			g_coinAmount = 0;
			g_billAmount = 0;
			return 0;
		}
	}
	else
	{
		//����ʧ��
		if(!ComStatus)
		{		
			TracePC("\r\n Appchange Fail");
			LogChangeAPI(tempmoney-backmoney,backmoney);//��¼��־
			PayoutRPTAPI(0,0,tempmoney-backmoney,0);
			//OSTimeDly(OS_TICKS_PER_SEC);
			//PayinRPTAPI(2,0,0);//�ϱ�PC��
			g_coinAmount = 0;
			g_billAmount = 0;
			return  backmoney;
		}
		//����ɹ�
		else
		{
			TracePC("\r\n Appchange succ%d",OSTimeGet());
			LogChangeAPI(tempmoney,0);//��¼��־
			PayoutRPTAPI(0,0,tempmoney,0);
			g_coinAmount = 0;
			g_billAmount = 0;
			return 0;
		}
	}	
}


/*********************************************************************************************************
** Function name:     	GetMoney
** Descriptions:	    �ص�����״̬ǰ����������׵�����
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void ClearDealPar()
{
	channelInput = 0;
	channelMode = 0;
	memset(BinNum,0,sizeof(BinNum));
	memset(ChannelNum,0,sizeof(ChannelNum));
	//g_Amount = 0;
	Timer.DispFreeTimer = 0;
	OSMboxAccept(g_CoinMoneyBackMail);
}

/*********************************************************************************************************
** Function name:     	BillCoinEnable
** Descriptions:	    ʹ�ܽ���ֽ����Ӳ����
** input parameters:    billCtr����ֽ����=1,ʹ��,2����,0������
                        coinCtr����Ӳ����=1,ʹ��,2����,0������
                        readerCtr���ƶ�����=1,ʹ��,2����,0������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void BillCoinCtr(uint8_t billCtr,uint8_t coinCtr,uint8_t readerCtr)
{
	//1.ֽ��������
	if(SystemPara.BillValidatorType != OFF_BILLACCEPTER)
	{
		switch(billCtr)
		{
			case 1:
				TraceBill("\r\n AppenBill");
				BillDevEnableAPI();
				SetBillCoinStatus(1,1);
				break;
			case 2:
				TraceBill("\r\n AppdisBill");
				BillDevDisableAPI();
				SetBillCoinStatus(1,0);
				break;
		}
	}
	//2.Ӳ��������
	if(SystemPara.CoinAcceptorType != OFF_COINACCEPTER)
	{
		switch(coinCtr)
		{
			case 1:
				TraceBill("\r\n AppenCoin");
				CoinDevEnableAPI();
				SetBillCoinStatus(2,1);
				break;
			case 2:
				TraceBill("\r\n AppdisCoin");
				CoinDevDisableAPI();
				SetBillCoinStatus(2,0);
				break;
		}
	}
	//3.����������
	if(SystemPara.CashlessDeviceType != OFF_READERACCEPTER)
	{
		switch(readerCtr)
		{
			case 1:
				ReaderDevEnableAPI();
				break;
			case 2:
				ReaderDevDisableAPI();
				break;
		}
	}
	OSTimeDly(OS_TICKS_PER_SEC / 10);
}

/*********************************************************************************************************
** Function name:     	ResetBill
** Descriptions:	    ����ֽ����
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void ResetBill()
{
	//1.ֽ��������
	if(SystemPara.BillValidatorType != OFF_BILLACCEPTER)
	{
		TraceBill("\r\n AppresetBill");
		BillDevResetAPI();
		SetBillCoinStatus(1,1);
	}	
	OSTimeDly(OS_TICKS_PER_SEC / 10);
}

/*********************************************************************************************************
** Function name:     	IsCanSale
** Descriptions:	    �ж��Ƿ���Գ���
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void IsCanSale()
{
	uint32_t tempPrice;
	//uint8_t resultdisp[8]={0, 0, 0, 0, 0, 0, 0, 0};
	//uint8_t recoin;
	unsigned char ComStatus = 0;
	uint32_t 	PriceSale  = 0;//��ǰ�������Ʒ

	PriceSale  = vmcPrice;
	//��Ʒ���۴�����Ͷ����,������ʹ���ֽ��׵�
	if((PriceSale > GetAmountMoney())&&(g_readerAmount==0))
	{
		vmcStatus = VMC_LESSMONEY;
	}
	//ʹ�ö���������
	else if(g_readerAmount > 0)
	{
		DispReaderDevVendoutRPT();
		ComStatus = ReaderDevVendoutRPTAPI(PriceSale);
		if(ComStatus == 1)
		{
			vmcStatus = VMC_CHUHUO;
		}
		else
		{
			vmcStatus = VMC_READVENDFAIL;
		}	
	}
	//��Ʒ���۴���ѹ����ֽ�Һ�Ͷ��Ӳ�ҽ��֮��
	else if(PriceSale > (g_coinAmount + g_billAmount))
	{
		tempPrice = PriceSale - g_coinAmount - g_billAmount;//��Ʒ���ۼ�ȥѹ����ֽ�Һ�Ͷ��Ӳ�ҽ��֮��
		tempPrice = g_holdValue - tempPrice;               //�ݴ�Ľ���ټ�ȥ��ʣ�µĽ�����Ҫ����Ľ��
		if(SystemPara.CoinChangerType == MDB_CHANGER)
		{
			//ComStatus = MDBchange(resultdisp, &recoin, tempPrice);//�����Щʣ��Ľ���Ƿ��������
			ComStatus = 1;
		}	
		else if(SystemPara.CoinChangerType == HOPPER_CHANGER)
		{
			ComStatus = 1;
		}
		else if(SystemPara.CoinChangerType == OFF_CHANGER)
		{
			//���ֽ��ѭ�������ã���������ֽ�ʣ���˿��Գ���
			if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
			{
				ComStatus = 1;
			}
			else
			{
				if(tempPrice==0)
					ComStatus = 1;
				else
					ComStatus = 0;
			}
		}
		//�����������
		if(ComStatus == 1)
		{
			//ѹ���ɹ�
			if(StackedBillDevMoneyInAPI())
			{				
				g_billAmount += g_holdValue;
				LogGetMoneyAPI(g_holdValue,2);//��¼��־
				PayinRPTAPI(2,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
				g_holdValue = 0;
				vmcStatus = VMC_CHUHUO;
			}
			//ѹ��ʧ��
			else
			{	
				ReturnBillDevMoneyInAPI();
				PayinRPTAPI(4,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
				g_holdValue = 0;
				vmcStatus = VMC_CHANGESHORT;
			}
		}
		else
		{
			vmcStatus = VMC_CHANGESHORT;
		}
	}
	//��Ʒ����С�ڵ���ѹ����ֽ�Һ�Ͷ��Ӳ�ҽ��֮��
	else
	{
		tempPrice = (g_coinAmount + g_billAmount) - PriceSale;//ֽ�Һ�Ͷ��Ӳ�ҽ��֮�ͼ�ȥ��Ʒ����
		if(SystemPara.CoinChangerType == MDB_CHANGER)
		{
			//ComStatus = MDBchange(resultdisp, &recoin, tempPrice);//�����Щʣ��Ľ���Ƿ��������
			ComStatus = 1;
		}	
		else if(SystemPara.CoinChangerType == HOPPER_CHANGER)
		{
			ComStatus = 1;
		}
		else if(SystemPara.CoinChangerType == OFF_CHANGER)
		{
			//���ֽ��ѭ�������ã���������ֽ�ʣ���˿��Գ���
			if(SystemPara.BillRecyclerType==MDB_BILLRECYCLER)
			{
				ComStatus = 1;
			}
			else
			{
				if(tempPrice==0)
					ComStatus = 1;
				else
					ComStatus = 0;
			}
		}
		//�����������
		if(ComStatus == 1)
		{
			if((SystemPara.BillITLValidator == ITL_BILLACCEPTER)&&(g_holdValue > 0))
			{
				//Trace("\r\n ITLReturn");
				ReturnBillDevMoneyInAPI();
				PayinRPTAPI(4,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
				g_holdValue = 0;
			}
			vmcStatus = VMC_CHUHUO;
		}
		else
		{
			vmcStatus = VMC_CHANGESHORT;
		}		
	}
}

/*********************************************************************************************************
** Function name:     	SaleCostMoney
** Descriptions:	    ������۳����
** input parameters:    PriceSale��������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void SaleCostMoney(uint32_t PriceSale)
{	
	
	//�۳�����
	if(PriceSale)
	{
		//����������ͽ��׳ɹ�
		if(g_readerAmount > 0)
		{
			TraceReader("\r\n AppCHuhuoSucc");
			ReaderDevVendoutResultAPI(1);
			g_readerAmount -= PriceSale;
			PriceSale = 0;
		}		
		else if(PriceSale >= g_billAmount)
		{
			PriceSale -= g_billAmount;
			g_billAmount = 0;
		}
		else
		{
			g_billAmount -= PriceSale;
			PriceSale = 0;
		}
	}
	if(PriceSale)
	{
		g_coinAmount -= PriceSale;					
	}	
}

/*********************************************************************************************************
** Function name:     	IsSaleTimeOver
** Descriptions:	    ���׵���ʱ��ʱ����������
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint8_t IsSaleTimeOver()
{
	if(SystemPara.SaleTime < 255)
	{
		if(Timer.SaleTimer == 0)
			return 1;
		else
			return 0;
	}
	else 
	{
		return 0;
	}	
}

/*********************************************************************************************************
** Function name:     	IsSaleTimeOver
** Descriptions:	    ���׵���ʱ��ʱ������
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
uint8_t SaleTimeSet(uint8_t haveSale)
{
	uint8_t SaleTimer;
	if(haveSale == 0)
	{
		SaleTimer = (15 + SystemPara.SaleTime) > 255? 255: (15 + SystemPara.SaleTime);
	}
	else if(haveSale == 1)
	{
		SaleTimer = SystemPara.SaleTime > 255? 255: SystemPara.SaleTime;
	}
	
	return SaleTimer;
}

/*********************************************************************************************************
** Function name:     	DispSaleTime
** Descriptions:	    ��ʾ���׵���ʱ
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void DispSaleTime()
{
	LCDPrintf(150,LINE1,0,SystemPara.Language,"%s%02d",BUSINESSDEAL[SystemPara.Language][17],Timer.SaleTimer);	
}

/*********************************************************************************************************
** Function name:     	StackMoneyInd
** Descriptions:	    ѹ���ݴ���,������״̬�仯,�ж��Ƿ����֧��
** input parameters:    PriceSale��������
** output parameters:   ��
** Returned value:      1����֧��,0������֧��
*********************************************************************************************************/
uint8_t StackMoneyInd(uint32_t PriceSale)
{
	uint8_t state=1;
	//�۳�����
	if(PriceSale)
	{
		if(PriceSale > (g_coinAmount + g_billAmount))
		{
			//ѹ���ɹ�
			if(StackedBillDevMoneyInAPI())
			{				
				g_billAmount += g_holdValue;
				//LogGetMoneyAPI(g_holdValue,2);//��¼��־
				PayinRPTAPI(2,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
				g_holdValue = 0;					
			}
			//ѹ��ʧ��
			else
			{	
				ReturnBillDevMoneyInAPI();
				PayinRPTAPI(4,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
				g_holdValue = 0;					
			}
		}
		TracePC("\r\n App Price=%ld,money=%ld",PriceSale,GetAmountMoney());
		if(GetAmountMoney() >= PriceSale)
			state = 1;
		else
			state = 0;
	}
	//2����״̬�仯
	if(GetAmountMoney())
	{					
		vmcStatus = VMC_SALE;
		Timer.SaleTimer = SaleTimeSet(0);
		if(vmcStatus == VMC_SALE)
		{
			//Trace("\r\n 1money=%ld",GetAmountMoney());
			if(g_billAmount< MoneyMaxin)							
				BillCoinCtr(1,1,0);
			//Trace("\r\n 2money=%ld",GetAmountMoney());
			channelInput = 0;
			channelMode = 0;
			memset(BinNum,0,sizeof(BinNum));
			memset(ChannelNum,0,sizeof(ChannelNum));
			//Trace("\r\n 3money=%ld",GetAmountMoney());
			OSMboxAccept(g_CoinMoneyBackMail);
			LCDClrScreen();
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			DispSalePage(0,hefangMode);
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			SaleSelectionKeyAPI(GetAmountMoney());
		}
	}							
	else
	{
		BillCoinCtr(1,1,0);
		channelInput = 0;
		channelMode = 0;
		memset(BinNum,0,sizeof(BinNum));
		memset(ChannelNum,0,sizeof(ChannelNum));
		//Trace("\r\n 3money=%ld",GetAmountMoney());
		OSMboxAccept(g_CoinMoneyBackMail);
		LCDClrScreen();
		DispEndPage();
		vmcStatus = VMC_END;
	}
	return state;
}
/*********************************************************************************************************
** Function name:     	CostMoneyInd
** Descriptions:	    ͨ��PC������������۳����
** input parameters:    PriceSale��������
** output parameters:   1�����ۿ�,0�������ۿ�
** Returned value:      ��
*********************************************************************************************************/
uint8_t CostReaderRPT(uint32_t PriceSale)
{
	uint8_t result=1,ComStatus=0;
	//�۳�����
	if(PriceSale)
	{
		//����������ͽ��׳ɹ�
		if(g_readerAmount > 0)
		{			
			DispReaderDevVendoutRPT();
			ComStatus = ReaderDevVendoutRPTAPI(PriceSale);			
			if(ComStatus == 0)
			{
				result=0;
			}
		}	
	}
	return result;
}

/*********************************************************************************************************
** Function name:     	CostMoneyInd
** Descriptions:	    ͨ��PC���۳����,������״̬�仯
** input parameters:    PriceSale��������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void CostMoneyInd(uint32_t PriceSale)
{
	//unsigned char ComStatus = 0;
	
	//�۳�����
	if(PriceSale)
	{
		//����������ͽ��׳ɹ�
		if(g_readerAmount > 0)
		{		
			TraceReader("\r\n AppPCCostSucc");
			ReaderDevVendoutResultAPI(1);
			g_readerAmount -= PriceSale;
			PriceSale = 0;			
		}	
		else
		{			
			if(PriceSale > (g_coinAmount + g_billAmount))
			{
				
				//ѹ���ɹ�
				if(StackedBillDevMoneyInAPI())
				{				
					g_billAmount += g_holdValue;
					//LogGetMoneyAPI(g_holdValue,2);//��¼��־
					PayinRPTAPI(2,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
					g_holdValue = 0;					
				}
				//ѹ��ʧ��
				else
				{	
					ReturnBillDevMoneyInAPI();
					PayinRPTAPI(4,g_holdValue,GetAmountMoney()-g_holdValue);//�ϱ�PC��
					g_holdValue = 0;					
				}
				OSTimeDly(OS_TICKS_PER_SEC*4);		
			}

			if(PriceSale >= g_billAmount)
			{
				PriceSale -= g_billAmount;
				g_billAmount = 0;
			}
			else
			{
				g_billAmount -= PriceSale;
				PriceSale = 0;
			}
		}
	}
	if(PriceSale)
	{
		g_coinAmount -= PriceSale;					
	}	


	//2����״̬�仯
	if(GetAmountMoney())
	{					
		vmcStatus = VMC_SALE;
		Timer.SaleTimer = SaleTimeSet(0);
		if(vmcStatus == VMC_SALE)
		{
			//Trace("\r\n 1money=%ld",GetAmountMoney());
			if(g_billAmount< MoneyMaxin)							
				BillCoinCtr(1,1,0);
			//Trace("\r\n 2money=%ld",GetAmountMoney());
			channelInput = 0;
			channelMode = 0;
			memset(BinNum,0,sizeof(BinNum));
			memset(ChannelNum,0,sizeof(ChannelNum));
			//Trace("\r\n 3money=%ld",GetAmountMoney());
			OSMboxAccept(g_CoinMoneyBackMail);
			LCDClrScreen();
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			DispSalePage(0,hefangMode);
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			SaleSelectionKeyAPI(GetAmountMoney());
		}
	}							
	else
	{
		BillCoinCtr(1,1,0);
		channelInput = 0;
		channelMode = 0;
		memset(BinNum,0,sizeof(BinNum));
		memset(ChannelNum,0,sizeof(ChannelNum));
		//Trace("\r\n 3money=%ld",GetAmountMoney());
		OSMboxAccept(g_CoinMoneyBackMail);
		LCDClrScreen();
		DispEndPage();
		vmcStatus = VMC_END;
	}
}

/*********************************************************************************************************
** Function name:     	VendoutInd
** Descriptions:	    ͨ��PC������,������״̬�仯
** input parameters:    PriceSale��������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void VendoutInd(uint16_t columnNo, uint32_t PriceSale,uint8_t Type)
{
	uint8_t ChuhuoRst = 0;
	char     ChannelVend[3] = {0};//ѡ�����ֵ

	DispChuhuoPagePC();
	BillCoinCtr(2,2,0);	

	TracePC("\r\n %dAppUboxVendout",OSTimeGet());	
	CostReaderRPT(PriceSale);
	//ActionRPTAPI(1,0,30,columnNo%100, Type,PriceSale,GetAmountMoney());
	ChuhuoRst = ChannelAPIProcess(columnNo%100,CHANNEL_OUTGOODS,columnNo/100);		
	//add by yoc 2013.12.16
	if((SystemPara.PcEnable == 1) || (SystemPara.PcEnable == 3))
	{
		if(ChuhuoRst == 1)
		{
			if(!GetAmountMoney())
				LogBeginTransAPI();
			if(Type == TRADE_CASH || Type == TRADE_ONE_CARD)
			{
				SaleCostMoney(PriceSale);//�ۿ�
				
			}
			ChannelNum[0] = 'A';
			ChannelNum[1] = (columnNo%100/10) + '0';
			ChannelNum[2] = (columnNo%100%10) + '0';
			vmcPrice = PriceSale;
			Trace("LogTransactionAPI logic=%c%c%c price=%d type=%x,tranNums=%d\r\n ",
				ChannelNum[0],ChannelNum[1],ChannelNum[2],vmcPrice,Type,transMul);
			LogTransactionAPI(vmcPrice,transMul++,ChannelNum,Type);//��¼��־
			VendoutRPTAPI(CHUHUO_OK, 1,columnNo%100, Type, PriceSale,GetAmountMoney(), ChannelGetParamValue(columnNo%100,2,columnNo/100) );		    					
			vmcStatus = VMC_QUHUO;
		}
		else
		{		
			DispChhuoFailPage();//add by yoc 2013.12.02
			VendoutRPTAPI(CHUHUO_ERR,1,columnNo%100, Type, PriceSale,GetAmountMoney(), ChannelGetParamValue(columnNo%100,2,columnNo/100) );		
		}
		
			
	}
	else if(SystemPara.PcEnable == 2)
	{
		if(ChuhuoRst==1)
		{
			DispQuhuoPage();		
			CostMoneyInd(PriceSale);
			ChannelVend[0] = columnNo%100/10+'0';
			ChannelVend[1] = columnNo%10+'0';
			LogBeginTransAPI();
			LogTransactionAPI(PriceSale,transMul++,ChannelVend,Type);//��¼��־
			VendoutRPTAPI( 0, columnNo/100,columnNo%100, Type, PriceSale,GetAmountMoney(), ChannelGetParamValue(columnNo%100,2,columnNo/100) );
		}
		else
		{	
			DispChhuoFailPage();
			if(g_readerAmount > 0)
			{
				ReaderDevVendoutResultAPI(2);
			}
			VendoutRPTAPI( 2, columnNo/100,columnNo%100, Type, PriceSale,GetAmountMoney(), ChannelGetParamValue(columnNo%100,2,columnNo/100) );		
		}	
		//2����״̬�仯
		if(GetAmountMoney())
		{					
			vmcStatus = VMC_SALE;
			Timer.SaleTimer = SaleTimeSet(0);
			if(vmcStatus == VMC_SALE)
			{
				//Trace("\r\n 1money=%ld",GetAmountMoney());
				if(g_billAmount< MoneyMaxin)							
					BillCoinCtr(1,1,0);
				//Trace("\r\n 2money=%ld",GetAmountMoney());
				channelInput = 0;
				channelMode = 0;
				memset(BinNum,0,sizeof(BinNum));
				memset(ChannelNum,0,sizeof(ChannelNum));
				//Trace("\r\n 3money=%ld",GetAmountMoney());
				OSMboxAccept(g_CoinMoneyBackMail);
				LCDClrScreen();
				//Trace("\r\n 4money=%ld",GetAmountMoney());
				DispSalePage(0,hefangMode);
				//Trace("\r\n 4money=%ld",GetAmountMoney());
				SaleSelectionKeyAPI(GetAmountMoney());
			}
		}							
		else
		{
			BillCoinCtr(1,1,0);
			channelInput = 0;
			channelMode = 0;
			memset(BinNum,0,sizeof(BinNum));
			memset(ChannelNum,0,sizeof(ChannelNum));
			//Trace("\r\n 3money=%ld",GetAmountMoney());
			OSMboxAccept(g_CoinMoneyBackMail);
			LCDClrScreen();
			vmcStatus = VMC_END;
		}
	}

	
	
}


/*********************************************************************************************************
** Function name:     	VendoutIndFail
** Descriptions:	    ͨ��PC������,��Ϊ����ԭ�����ʧ��
** input parameters:    PriceSale��������
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void VendoutIndFail(uint16_t columnNo, uint32_t PriceSale,uint8_t Type,uint8_t status)
{	
	if(SystemPara.PcEnable == 2)
	{			
		VendoutRPTAPI( status, columnNo/100,columnNo%100, Type, PriceSale,GetAmountMoney(), ChannelGetParamValue(columnNo%100,2,columnNo/100) );		
	}
}



/*********************************************************************************************************
** Function name:     	ResetInd
** Descriptions:	    PC���·�������λָ��
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void ResetInd()
{
	if(GetAmountMoney())
	{
		ChangerMoney();
		OSTimeDly(OS_TICKS_PER_SEC*2);
		channelInput = 0;
		channelMode = 0;
		memset(BinNum,0,sizeof(BinNum));
		memset(ChannelNum,0,sizeof(ChannelNum));
		//Trace("\r\n 3money=%ld",GetAmountMoney());
		OSMboxAccept(g_CoinMoneyBackMail);
		LCDClrScreen();
		DispEndPage();
		vmcStatus = VMC_END;
	}
	BillCoinCtr(2,2,0);
	OSTimeDly(OS_TICKS_PER_SEC);
	MdbBusHardwareReset();
	OSTimeDly(OS_TICKS_PER_SEC*2);
	BillCoinCtr(1,1,0);
}


/*********************************************************************************************************
** Function name:     	TuiMoneyInd
** Descriptions:	    PC���·��˱�ָ��
** input parameters:    
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void TuiMoneyInd()
{
	uint32_t debtMoney;
	//����������������
	if((SystemPara.CashlessDeviceType != OFF_READERACCEPTER)&&(GetReaderAmount()))
	{
	}
	else if(GetAmountMoney())
	{
		DispPayoutPage();
		TracePC("\r\n AppTui%d",OSTimeGet());
		ActionRPTAPI(2,0,30,0,1,GetAmountMoney(),GetAmountMoney());
		OSTimeDly(OS_TICKS_PER_SEC*2);
		debtMoney = ChangerMoney();
		if(debtMoney)
		{
			DispIOUPage(debtMoney);
		}
		else
		{
			DispQuChangePage();
		}
		vmcStatus = VMC_END;
	}
	else
	{
		DispPayoutPage();
		TracePC("\r\n Appchange Fail");
		LogChangeAPI(0,0);//��¼��־
		if(SystemPara.EasiveEnable == 1)
		{
			PayoutRPTAPI(0,0,0,0);
		}
		//OSTimeDly(OS_TICKS_PER_SEC);
		//PayinRPTAPI(2,0,0);//�ϱ�PC��
		g_coinAmount = 0;
		g_billAmount = 0;
		vmcStatus = VMC_END;
	}
}


/*********************************************************************************************************
** Function name:     	VendoutSIMPLEInd
** Descriptions:	    PC�����ͳ���,������״̬�仯
** input parameters:    
** output parameters:   ��
** Returned value:      1�ɹ�,0ʧ��
*********************************************************************************************************/
uint8_t VendoutSIMPLEInd(uint16_t columnNo)
{
	uint8_t ChuhuoRst = 0;

	DispChuhuoPagePC();
	
	TracePC("\r\n %dAppUboxVendout",OSTimeGet());	
	//ActionRPTAPI(1,0,30,columnNo%100, Type,PriceSale,GetAmountMoney());
	ChuhuoRst = ChannelAPIProcess(columnNo%100,CHANNEL_OUTGOODS,columnNo/100);	
	//2����״̬�仯
	if(GetAmountMoney())
	{					
		vmcStatus = VMC_SALE;
		Timer.SaleTimer = SaleTimeSet(0);
		if(vmcStatus == VMC_SALE)
		{
			//Trace("\r\n 1money=%ld",GetAmountMoney());
			if(g_billAmount< MoneyMaxin)							
				BillCoinCtr(1,1,0);
			//Trace("\r\n 2money=%ld",GetAmountMoney());
			channelInput = 0;
			channelMode = 0;
			memset(BinNum,0,sizeof(BinNum));
			memset(ChannelNum,0,sizeof(ChannelNum));
			//Trace("\r\n 3money=%ld",GetAmountMoney());
			OSMboxAccept(g_CoinMoneyBackMail);
			LCDClrScreen();
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			DispSalePage(0,hefangMode);
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			SaleSelectionKeyAPI(GetAmountMoney());
		}
	}							
	else
	{
		BillCoinCtr(1,1,0);
		channelInput = 0;
		channelMode = 0;
		memset(BinNum,0,sizeof(BinNum));
		memset(ChannelNum,0,sizeof(ChannelNum));
		//Trace("\r\n 3money=%ld",GetAmountMoney());
		OSMboxAccept(g_CoinMoneyBackMail);
		LCDClrScreen();
		vmcStatus = VMC_END;
	}
	return ChuhuoRst;
	
}

/*********************************************************************************************************
** Function name:     	GetmoneySIMPLEInd
** Descriptions:	    PC�����ͽ��,������״̬�仯
** input parameters:    
** output parameters:   ��
** Returned value:      
*********************************************************************************************************/
void GetmoneySIMPLEInd(uint16_t payInMoney)
{
	uint32_t g_yuanAmount = 0;

	g_yuanAmount = GetAmountMoney();
	g_readerAmount=payInMoney;
	//2����״̬�仯
	if(GetAmountMoney())
	{					
		vmcStatus = VMC_SALE;
		Timer.SaleTimer = SaleTimeSet(0);
		if(vmcStatus == VMC_SALE)
		{
			//Trace("\r\n 1money=%ld",GetAmountMoney());
			if(g_billAmount< MoneyMaxin)							
				BillCoinCtr(1,1,0);
			//Trace("\r\n 2money=%ld",GetAmountMoney());
			channelInput = 0;
			channelMode = 0;
			memset(BinNum,0,sizeof(BinNum));
			memset(ChannelNum,0,sizeof(ChannelNum));
			//Trace("\r\n 3money=%ld",GetAmountMoney());
			OSMboxAccept(g_CoinMoneyBackMail);
			LCDClrScreen();
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			DispSalePage(0,hefangMode);
			//Trace("\r\n 4money=%ld",GetAmountMoney());
			SaleSelectionKeyAPI(GetAmountMoney());
		}
	}							
	else
	{
		BillCoinCtr(1,1,0);
		channelInput = 0;
		channelMode = 0;
		memset(BinNum,0,sizeof(BinNum));
		memset(ChannelNum,0,sizeof(ChannelNum));
		//Trace("\r\n 3money=%ld",GetAmountMoney());
		OSMboxAccept(g_CoinMoneyBackMail);
		if(g_yuanAmount>0)
		{
			LCDClrScreen();
			vmcStatus = VMC_END;
		}
	}
	
}

/*********************************************************************************************************
** Function name:     	GetmoneySIMPLEInd
** Descriptions:	    PC��������Ʒ���۽��,������״̬�仯
** input parameters:    
** output parameters:   ��
** Returned value:      
*********************************************************************************************************/
void PriceSIMPLEInd(uint16_t payInMoney)
{
	uint16_t debtMoney=0;
	char strlanguage[30] = {0},streng[30] = {0};
	
	//1.��ʾ����	
	Timer.ChaxunTimer = 5;
	if(GetAmountMoney() == 0)
	{
		DispChaxunFreePage();
	}
	debtMoney = payInMoney;
	switch(SystemPara.DecimalNum) 
	{
	  case 2://�Է�Ϊ��λ
		  sprintf(strlanguage,"%s%02d.%02d",BUSINESS[SystemPara.Language][3],debtMoney/100,debtMoney%100);
		  sprintf(streng,"%s%02d.%02d",BUSINESS[1][3],debtMoney/100,debtMoney%100); 
		  break;

	  case 1://�Խ�Ϊ��λ
		  debtMoney /= 10;
		  sprintf(strlanguage,"%s%d.%d",BUSINESS[SystemPara.Language][3],debtMoney/10,debtMoney%10);
		  sprintf(streng,"%s%d.%d",BUSINESS[1][3],debtMoney/10,debtMoney%10);
		  break;
	  
	  case 0://��ԪΪ��λ
		  sprintf(strlanguage,"%s%d",BUSINESS[SystemPara.Language][3],debtMoney/100);
		  sprintf(streng,"%s%d",BUSINESS[1][3],debtMoney/100);
		  break;
	}	
	//strcpy(streng,BUSINESS[1][3]);
	DispBusinessText(strlanguage,streng,"","");
	OSTimeDly(OS_TICKS_PER_SEC*3);
	
	
	//2��ʱ�˳���ѯҳ��
	if(Timer.ChaxunTimer == 0)
	{
		if(GetAmountMoney() > 0)
		{				
			vmcStatus = VMC_SALE;
		}
		else
		{
			ClearDealPar(); 	
			CLrBusinessText();
			vmcStatus = VMC_FREE;
		}
		rstTime();
	}
	if(vmcStatus == VMC_SALE)
	{	
		DispSalePage(0,hefangMode);					
	}
	else if(vmcStatus == VMC_FREE)
	{
		LCDClrScreen();
		rstTime();
	}
}

/*********************************************************************************************************
** Function name:     	TxtSIMPLEInd
** Descriptions:	    PC�������ַ���,������״̬�仯
** input parameters:    
** output parameters:   ��
** Returned value:      
*********************************************************************************************************/
void TxtSIMPLEInd(char *disp)
{
	//uint16_t debtMoney=0;
	char strlanguage[30] = {0},streng[30] = {0};
	//2����״̬�仯
	if(GetAmountMoney())
	{
		GetmoneySIMPLEInd(0);
	}
	sprintf(strlanguage,"%s",disp);
	sprintf(streng,"%s",disp);
	LCDPrintf(80,LINE15,0,SystemPara.Language,streng);
	
	
}


/*********************************************************************************************************
** Function name:     	BusinessProcess
** Descriptions:	    ��������
** input parameters:    ��
** output parameters:   ��
** Returned value:      ��
*********************************************************************************************************/
void BusinessProcess(void *pvData)
{	
	uint8_t keyValue = 0;//����ֵ
	uint8_t moneyGet = 0;//�Ƿ��Ѿ���Ǯ��
	uint8_t haveSale = 0;//0��һ�ι���,1�ڶ������Ϲ���	
	uint32_t debtMoney;	
	uint8_t ChuhuoRst = 0;
	uint8_t keyMode = 0;
	
	
	//OSTimeDly(OS_TICKS_PER_SEC);
	Timer.DispFreeTimer = 0;
	Timer.CheckDevStateTimer = 0;	
	Timer.GetTubeTimer = 0;
	Timer.ChaxunTimer = 0;
	//Trace("\r\n 3.de=%ld,%ld,%ld",LogParaDetail.IncomeBill,LogParaDetail.IncomeCoin,LogParaDetail.IncomeCard);
#if 0
	//�Ƿ���ѹ������չʾ��
	if(UserPara.CompressorCtr.flag==1)
	{
		API_ACDCHandle(UserPara.LEDCtr.flag,1,OPENCOMPRESSOR);
	}
	else
	if(UserPara.CompressorCtr.flag==0)
	{
		API_ACDCHandle(UserPara.LEDCtr.flag,1,CLOSECOMPRESSOR);
	}
	if(UserPara.LEDCtr.flag==1)
	{
		API_ACDCHandle(UserPara.CompressorCtr.flag,1,OPENLIGHT);
	}
	else
	if(UserPara.LEDCtr.flag==0)
	{
		API_ACDCHandle(UserPara.CompressorCtr.flag,1,CLOSELIGHT);
	}
	Trace("ACDCFlag=%d  %d\r\n",UserPara.CompressorCtr.flag,UserPara.LEDCtr.flag);
#endif

	//5.�Ƿ����ά��״̬
	if(ReadMaintainKeyValue())
	{
		BillCoinCtr(2,2,2);
		vmcStatus = VMC_WEIHU;
	}
	PriceMaxin = ChannelGetMaxGoodsPrice(1);
	//���ÿ���״̬��չʾ�ƵĿ���
	if(SystemPara.threeSelectKey==1)
		FreeSelectionKeyValueAPI();
	else
		FreeSelectionKeyAPI(1);
	gameLedControl(1);//����Ϸ��
	
	
	LCDClrScreen();
	while(1)
	{	
		//������ѵPC��������add by yoc 2014.04.22
		mainTaskPollPC(vmcStatus);
		
		switch(vmcStatus)
		{
			case VMC_FREE:
				if(GOCCHECKTIMEOUT>200)
				{
					GOCCHECKTIMEOUT = 0;
					//ChannelGetGocState(1);
				}

				//1.��ʾ����ҳ��
				if(Timer.DispFreeTimer==0)
				{
					Timer.DispFreeTimer = 5;
					DispFreePage();
					WaitForPCInit();
				}
				//2.��ѯ����
				keyValue = KeyValueAPI(0,&keyMode);
				if(keyValue)
				{
					//��Ч������ѯ�з��񵥼�
					if((keyValue == '<')||(keyValue == '>'))
					{
						channelInput = 0;
						channelMode = 0;
					}
					else
					{
						Timer.ChaxunTimer = 5;
						vmcStatus = VMC_CHAXUN;
					}
				}
				//3.��ѯӲ����������Ӳ��
				if(Timer.GetTubeTimer==0)
				{
					Timer.GetTubeTimer = 5;
					UnpdateTubeMoney();
				}
				//3.��ѯͶֽ�Һ�Ӳ�ҽ��	
				moneyGet = GetMoney();
				if(moneyGet == 1)
				{
					ClrTuibiAPI();
					LCDClrScreen();
					DispSalePage(haveSale,hefangMode);
					TraceBill("\r\n App2amount=%ld",GetAmountMoney());
					LogBeginTransAPI();//��¼����ϸ��־��
					Timer.SaleTimer = SaleTimeSet(haveSale);
					SaleSelectionKeyAPI(GetAmountMoney());
					vmcStatus = VMC_SALE;
				}
				//4.����豸����״̬
				if(Timer.CheckDevStateTimer==0)
				{
					Timer.CheckDevStateTimer = 5;
					CheckDeviceState();					
					if(IsErrorState())
					{
						Timer.DispFreeTimer=0;
						StatusRPTAPI();
						OSTimeDly(OS_TICKS_PER_SEC/2);
						LCDClrScreen();
						BillCoinCtr(2,2,2);
						rstTime();
						vmcStatus = VMC_ERROR;
					}
					else
					{
						BillStatusRPTAPI();//�ж�ֽ�����Ƿ���ϻ�ָ����ϱ���pc
					}
				}
				//5.�Ƿ����ά��״̬
				if(ReadMaintainKeyValue())
				{
					BillCoinCtr(2,2,2);
					vmcStatus = VMC_WEIHU;
				}
				//6.�Լ�ѹ������չʾ��
				ACDCTimingHandle(1);
				//7.���pc����ѯ
				PollAPI(GetAmountMoney());
				//8.�ӽ���Ӧ��� add by yoc 2013.11.13
				pollHuman(ReadCloseHumanKeyValue());
				//9��ѯ���Ŵ����� add by yoc 2013.11.13
				pollDoorAPI(0);
				//10.��ѯ��Ϸ����
				ReadGameKeyValueAPI();
				break;
			case VMC_CHAXUN:
				//1.��ѯ����
				if(keyValue)
				{
					TraceSelection("\r\n AppKey2=%d",keyValue);
					Timer.ChaxunTimer = 5;
					if(GetAmountMoney() == 0)
					{
						DispChaxunFreePage();
					}
					DispChaxunPage(&keyValue,&keyMode);
				}
				keyValue = KeyValueAPI(1,&keyMode);
				
				//2��ʱ�˳���ѯҳ��
				if(Timer.ChaxunTimer == 0)
				{
					keyValue = 'C';
					keyMode = 2;
					rstTime();
				}
				if(vmcStatus == VMC_SALE)
				{	
					DispSalePage(haveSale,hefangMode);					
				}
				else if(vmcStatus == VMC_FREE)
				{
					LCDClrScreen();
					rstTime();
				}
				break;
			case VMC_CHAXUNHEFANG:
				//1.��ѯ����
				if(keyValue)
				{
					Timer.ChaxunTimer = 20;
					if(GetAmountMoney() == 0)
					{
						DispChaxunFreePage();
					}
					DispChaxunHefangPage(&keyValue);
				}
				keyValue = KeyValueAPI(1,&keyMode);
				
				//2��ʱ�˳���ѯҳ��
				if(Timer.ChaxunTimer == 0)
				{
					keyValue = 'C';
					keyMode = 2;
				}				
				if(vmcStatus == VMC_SALE)
				{
					DispSalePage(haveSale,hefangMode);
				}
				else if(vmcStatus == VMC_FREE)
				{
					LCDClrScreen();
				}
				break;
			case VMC_SALE:
				//1.��ѯͶֽ�Һ�Ӳ�ҽ��
				//i=0;
				//Trace("\r\n u=%d",i++);
				//Trace("\r\n VMC_SALE");
				moneyGet = GetMoney();
				if(moneyGet == 1)
				{
					DispSalePage(haveSale,hefangMode);
					Timer.SaleTimer = SaleTimeSet(haveSale);
					SaleSelectionKeyAPI(GetAmountMoney());
					TraceBill("\r\n App2amount=%ld",GetAmountMoney());	 				
				}
				//2.��ѯ����
				//Trace("\r\n u=%d",i++);
				keyValue = KeyValueAPI(0,&keyMode);
				//keyValue = 0;
				if(keyValue)
				{			
					TraceSelection("\r\n AppKey1=%d",keyValue);
					Timer.ChaxunTimer = 5;
					vmcStatus = VMC_CHAXUN;	
					break;
				}
				//Trace("\r\n u=%d",i++);
				//�а����˱Ұ���
				if(
					//�а����˱Ұ���     ���߽���ʱ�����
					(IsTuibiAPI()||(IsSaleTimeOver()) )
					//      ǿ�ƹ���                �����Ѿ����׹�һ�������� 
					&&((UserPara.TransEscape == 0)||(haveSale == 1))
					//������������˱���Ч
					&&(g_readerAmount == 0)
				)
				{
					BillCoinCtr(2,2,0);
					vmcStatus = VMC_PAYOUT;					
				}
				//Trace("\r\n u=%d",i++);
				//��ʾ����ʱ
				if( 
					(SystemPara.SaleTime < 255) 
					//      �����������˱�          �����Ѿ����׹�һ��������
					&&((UserPara.TransEscape == 0)||(haveSale == 1))
					//������������˱���Ч
					&&(g_readerAmount == 0)
				)
				{
					DispSaleTime();
				}
				if(moneyGet == 2)
				{					
					vmcStatus = VMC_END;
				}
				//7.���pc����ѯ
				PollAPI(GetAmountMoney());
				//8.��ѯ��Ϸ����
				ReadGameKeyValueAPI();
				break;
			case VMC_OVERVALUE:
				break;
			case VMC_XUANHUO:
				IsCanSale();				
				break;
			case VMC_WUHUO:
				break;
			case VMC_LESSMONEY:
				DispCannotBuyPage(vmcPrice);
				Timer.SaleTimer = SaleTimeSet(haveSale);
				vmcStatus = VMC_SALE;
				channelInput = 0;
				channelMode = 0;
				memset(BinNum,0,sizeof(BinNum));
				memset(ChannelNum,0,sizeof(ChannelNum));
				OSMboxAccept(g_CoinMoneyBackMail);
				vmcPrice = 0;
				DispSalePage(haveSale,hefangMode);
				break;
			case VMC_CHANGESHORT:
				DispCannotBuyAsPayoutPage();
				if(GetAmountMoney())
				{
					Timer.SaleTimer = SaleTimeSet(haveSale);
					vmcStatus = VMC_SALE;
					channelInput = 0;
					channelMode = 0;
					memset(BinNum,0,sizeof(BinNum));
					memset(ChannelNum,0,sizeof(ChannelNum));
					OSMboxAccept(g_CoinMoneyBackMail);
					vmcPrice = 0;
					DispSalePage(haveSale,hefangMode);
				}
				else
				{
					vmcStatus = VMC_END;
				}
				break;
			case VMC_READVENDFAIL:
				DispReaderVendoutFail();
				vmcStatus = VMC_SALE;
				channelInput = 0;
				channelMode = 0;
				memset(BinNum,0,sizeof(BinNum));
				memset(ChannelNum,0,sizeof(ChannelNum));
				OSMboxAccept(g_CoinMoneyBackMail);
				vmcPrice = 0;
				DispSalePage(haveSale,hefangMode);
				break;	
			case VMC_CHUHUO:
				BillCoinCtr(2,2,0);
				DispChuhuoPage();
					

				//ActionRPTAPI(1,0,30,vmcColumn%100, 0,vmcPrice,GetAmountMoney());
                //OSTimeDly(OS_TICKS_PER_SEC / 2);
				ChuhuoRst = ChannelAPIProcess(vmcColumn%100,CHANNEL_OUTGOODS,vmcColumn/100);		
				if(ChuhuoRst==1)
				{
					SaleCostMoney(vmcPrice);//�ۿ�
				
					//Trace("\r\n money=%d\r\n",GetAmountMoney());	
					
					//��¼��־�����ѽ��
					if(g_readerAmount > 0)
					{
						LogTransactionAPI(vmcPrice,transMul++,ChannelNum,2);//��¼����־
					}
					else
					{
						LogTransactionAPI(vmcPrice,transMul++,ChannelNum,0);//��¼��־
						ReaderDevCashSaleAPI(vmcPrice);
					}
					VendoutRPTAPI( 0, vmcColumn/100,vmcColumn%100, 0, vmcPrice,GetAmountMoney(), ChannelGetParamValue(vmcColumn%100,2,vmcColumn/100) );
					vmcStatus = VMC_QUHUO;
				}
				else
				{
					//����������ͽ���ʧ��
					if(g_readerAmount > 0)
					{
						TraceReader("\r\n AppCHuhuoFail");
						ReaderDevVendoutResultAPI(2);
					}	
					if(SystemPara.PcEnable == 1 || SystemPara.PcEnable == 3)
					{
						VendoutRPTAPI( CHUHUO_ERR, 1,vmcColumn%100, 0, vmcPrice,GetAmountMoney(), ChannelGetParamValue(vmcColumn%100,2,vmcColumn/100) );
					}
					else
						VendoutRPTAPI( 2, vmcColumn/100,vmcColumn%100, 0, vmcPrice,GetAmountMoney(), ChannelGetParamValue(vmcColumn%100,2,vmcColumn/100) );
					vmcStatus = VMC_CHUHUOFAIL;
				}
				vmcPrice = 0;
				break;
			case VMC_QUHUO:
				DispQuhuoPage();
//				if(SystemPara.ChannelType == 2)
//				{
//					while(1)
//					{
//						ChuhuoRst = LiftTableProcess(vmcColumn/100,vmcColumn%100,LIFTTABLE_TAKEGOODS);	
//						if(ChuhuoRst == 1)	
//							break;
//					}
//				}
				//��ι���
				if( (UserPara.TransMultiMode == 1)&&(GetAmountMoney()) )
				{					
					vmcStatus = VMC_SALE;
					haveSale = 1;
					Timer.SaleTimer = SaleTimeSet(haveSale);
					if(vmcStatus == VMC_SALE)
					{
						//Trace("\r\n 1money=%ld",GetAmountMoney());
						if(g_billAmount< MoneyMaxin)						
							BillCoinCtr(1,1,0);
						else
							BillCoinCtr(0,1,0);	
						//Trace("\r\n 2money=%ld",GetAmountMoney());
						channelInput = 0;
						channelMode = 0;
						memset(BinNum,0,sizeof(BinNum));
						memset(ChannelNum,0,sizeof(ChannelNum));
						//Trace("\r\n 3money=%ld",GetAmountMoney());
						OSMboxAccept(g_CoinMoneyBackMail);
						LCDClrScreen();
						//Trace("\r\n 4money=%ld",GetAmountMoney());
						DispSalePage(haveSale,hefangMode);
						//Trace("\r\n 4money=%ld",GetAmountMoney());
						SaleSelectionKeyAPI(GetAmountMoney());
						keyValue = KeyValueAPI(0,&keyMode);
					}
				}
				else if(GetAmountMoney())
				{
					DispSalePage(haveSale,hefangMode);
					vmcStatus = VMC_PAYOUT;
				}
				else
				{
					vmcStatus = VMC_END;
				}
				break;
			case VMC_CHUHUOFAIL:
				
				DispChhuoFailPage();
				//��ι���
				if(GetAmountMoney())
				{					
					vmcStatus = VMC_SALE;
					haveSale = 1;
					Timer.SaleTimer = SaleTimeSet(haveSale);
					if(vmcStatus == VMC_SALE)
					{
						if(g_billAmount< MoneyMaxin)							
							BillCoinCtr(1,1,0);
						else
							BillCoinCtr(0,1,0);
						channelInput = 0;
						channelMode = 0;
						memset(BinNum,0,sizeof(BinNum));
						memset(ChannelNum,0,sizeof(ChannelNum));
						OSMboxAccept(g_CoinMoneyBackMail);
						LCDClrScreen();
						DispSalePage(haveSale,hefangMode);
					}
				}
				break;
			case VMC_PAYOUT:				
				DispPayoutPage();
				debtMoney = ChangerMoney();
				if(debtMoney)
				{
					DispIOUPage(debtMoney);
				}
				else
				{
					DispQuChangePage();
				}
				vmcStatus = VMC_END;
				break;
			case VMC_END:				
				DispEndPage();
				ClearDealPar();
				haveSale = 0;
				transMul = 0;
				vmcColumn = 0;	
				hefangMode = 0;
				Timer.GetTubeTimer = 0;
				BillCoinCtr(1,1,1);
				vmcChangeLow = 0;
				rstTime();
				PriceMaxin = ChannelGetMaxGoodsPrice(1);
				LogEndTransAPI();//��¼����־��
				if(SystemPara.threeSelectKey==1)
					FreeSelectionKeyValueAPI();
				else
					FreeSelectionKeyAPI(1);
				
				//UnpdateTubeMoney();
				LCDClrScreen();
				vmcStatus = VMC_FREE;
				break;
			case VMC_ERROR:	
				//1.��ʾ����ҳ��
				if(Timer.DispFreeTimer==0)
				{
					Timer.DispFreeTimer = 30;
					DispErrPage();
				}	
				//2.����豸�Ƿ�ָ�����
				if(Timer.CheckDevStateTimer==0)
				{
					Timer.CheckDevStateTimer = 5;
					CheckDeviceState();
					//6.�Լ�ѹ������չʾ��
					ACDCTimingHandle(1);
					if(!IsErrorState())
					{	
						Timer.DispFreeTimer=0;
						LCDClrScreen();
						BillCoinCtr(1,1,1);
						OSTimeDly(OS_TICKS_PER_SEC/2);
						StatusRPTAPI();
						rstTime();
						vmcStatus = VMC_FREE;
					}
					PollAPI(GetAmountMoney());
				}
				//3.�Ƿ����ά��״̬
				if(ReadMaintainKeyValue())
				{
					vmcStatus = VMC_WEIHU;
				}
				//4.�Լ�ѹ������չʾ��
				//ACDCTimingHandle(1);
				//5.��ѯӲ����������Ӳ��
				//if(Timer.GetTubeTimer==0)
				//{
				//	Timer.GetTubeTimer = 5;
				//	UnpdateTubeMoney();
				//}
				//6.��ѯͶֽ�Һ�Ӳ�ҽ��	
				moneyGet = GetMoney();
				if(moneyGet == 1)
				{
					ClrTuibiAPI();
					LCDClrScreen();
					DispSalePage(haveSale,hefangMode);
					TraceBill("\r\n App2amount=%ld",GetAmountMoney());
					LogBeginTransAPI();//��¼����ϸ��־��
					vmcStatus = VMC_ERRORSALE;
				}
				break;
			case VMC_ERRORSALE:	
				//1.��ѯͶֽ�Һ�Ӳ�ҽ��
				//i=0;
				//Trace("\r\n u=%d",i++);
				//Trace("\r\n VMC_SALE");
				moneyGet = GetMoney();
				if(moneyGet == 1)
				{
					DispSalePage(haveSale,hefangMode);
					TraceBill("\r\n App2amount=%ld",GetAmountMoney());	 				
				}
				//�а����˱Ұ���
				if(
					//�а����˱Ұ���     
					IsTuibiAPI()
					//������������˱���Ч
					&&(g_readerAmount == 0)
				)
				{
					BillCoinCtr(2,2,0);
					vmcStatus = VMC_ERRORPAYOUT;					
				}				
				if(moneyGet == 2)
				{
					vmcStatus = VMC_ERROREND;
				}
				//7.���pc����ѯ
				PollAPI(GetAmountMoney());
				break;
			case VMC_ERRORPAYOUT:
				DispPayoutPage();
				debtMoney = ChangerMoney();
				if(debtMoney)
				{
					DispIOUPage(debtMoney);
				}
				else
				{
					DispQuChangePage();
				}
				vmcStatus = VMC_ERROREND;
				break;
			case VMC_ERROREND:				
				DispEndPage();
				ClearDealPar();
				haveSale = 0;
				transMul = 0;
				vmcColumn = 0;
				LCDClrScreen();
				BillCoinCtr(1,1,0);
				LogEndTransAPI();//��¼����־��
				rstTime();
				vmcStatus = VMC_ERROR;
				break;	
			case VMC_WEIHU:
				FreeSelectionKeyAPI(0);	
				/*
				SetWeihuStatus(1);
				StatusRPTAPI();
				OSTimeDly(OS_TICKS_PER_SEC);
				ActionRPTAPI(5,1,0,0,0,0,0);
				*/
				if(SystemPara.PcEnable)
				{
					//ActionRPTAPI(5,1,0,0,0,0,0);
					SetWeihuStatus(1);
					if(SystemPara.EasiveEnable == 0)
					{
						OSTimeDly(OS_TICKS_PER_SEC);
						StatusRPTAPI();
						OSTimeDly(OS_TICKS_PER_SEC);
					}
				}
				
				do
				{
					//7.���pc����ѯ
					PollAPI(GetAmountMoney());
					MaintainUserProcess((void*)0);
				}
				while(ReadMaintainKeyValue());
				Timer.DispFreeTimer=0;
				LCDClrScreen();
				BillCoinCtr(1,1,1);
				vmcChangeLow = 0;
				rstTime();
				if(SystemPara.PcEnable)
				{
					ActionRPTAPI(5,0,0,0,0,0,0);
					SetWeihuStatus(0);
					if(SystemPara.EasiveEnable == 0)
					{
						OSTimeDly(OS_TICKS_PER_SEC);
						StatusRPTAPI();
						OSTimeDly(OS_TICKS_PER_SEC);
					}
					//globalSys.pcInitFlag = 0;
				}
				PriceMaxin = ChannelGetMaxGoodsPrice(1);
				//���ÿ���״̬��չʾ�ƵĿ���
				if(SystemPara.threeSelectKey==1)
					FreeSelectionKeyValueAPI();
				else
					FreeSelectionKeyAPI(1);
				
				vmcStatus = VMC_FREE;
				break;
		}		
		OSTimeDly(OS_TICKS_PER_SEC / 100);
	}	
}
/**************************************End Of File*******************************************************/
