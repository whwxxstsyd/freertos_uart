#ifndef _ACDC_H
#define _ACDC_H


void ACDCManageLight(void);

void ACDCManageCompressor(void);

void ACDCTimingHandle(unsigned char Binnum);
void acdc_controlHot(void);
void acdc_controlChuchou(void);




#endif
