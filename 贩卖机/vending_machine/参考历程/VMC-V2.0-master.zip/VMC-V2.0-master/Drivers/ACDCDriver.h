#ifndef _ACDCDRIVER_H
#define _ACDCDRIVER_H



unsigned char ACDCHandle(unsigned char Add,unsigned short nData);



#endif
