#ifndef _TUIBIAPI_H

extern	uint8_t IsTuibiAPI(void);

extern	void ClrTuibiAPI(void);


#endif

