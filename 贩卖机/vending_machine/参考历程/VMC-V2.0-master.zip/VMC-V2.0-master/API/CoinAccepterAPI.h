#ifndef _COINACCEPTERAPI_H


//extern void BillDevSellect(void);

extern void CoinDevInitAPI(void);


extern void CoinDevDisableAPI(void);

extern void CoinDevEnableAPI(void);

extern uint32_t GetCoinDevMoneyInAPI(void);


#endif
