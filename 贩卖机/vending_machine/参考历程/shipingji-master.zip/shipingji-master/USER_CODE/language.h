#ifndef __LANGUAGE_H 
#define __LANGUAGE_H
#ifdef __cplusplus
extern "C" {
#endif                                                                  /*  __cplusplus                 */

extern   const char *   Language[24][4];



#ifdef __cplusplus
    }
#endif                                                                  /*  __cplusplus                 */

#endif
