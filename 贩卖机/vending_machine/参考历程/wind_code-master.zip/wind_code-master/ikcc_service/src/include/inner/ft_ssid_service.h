#ifndef FT_SSID_SERVICE_H
#define FT_SSID_SERVICE_H

int ikcc_init_ssid_tcp_server(int port);


#endif /* FT_SSID_SERVICE_H */
