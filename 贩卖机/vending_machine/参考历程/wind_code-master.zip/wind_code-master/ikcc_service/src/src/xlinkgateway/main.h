/*
 * main.h
 *
 *  Created on: 2016年12月20日
 *      Author: john
 */

#ifndef MAIN_H_
#define MAIN_H_

extern int ConsoleDiscoverDevice(char *args);
extern int ConsoleRestartNofify(char *args);
#endif /* MAIN_H_ */
