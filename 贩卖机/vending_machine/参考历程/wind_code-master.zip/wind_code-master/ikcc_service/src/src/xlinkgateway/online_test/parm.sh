#!/bin/sh

echo $#,$@