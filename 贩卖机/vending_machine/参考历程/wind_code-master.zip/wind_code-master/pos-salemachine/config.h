#ifndef _CONFIG_H_
#define _CONFIG_H_

#define POS_DEV		"/dev/ttyS1"
#define POS_BPS		115200
#define POS_PAR		'N'
#define POS_BLOCK	 0
#define POS_UNBLOCK	 1

#define FJ_DEV		"/dev/ttyS2"
#define FJ_BPS		4800
#define FJ_PAR		'E'
#define FJ_BLOCK	 0
#define FJ_UNBLOCK	 1


#endif
