#ifndef _UTILS_H_
#define _UTILS_H_

void debug_buf(unsigned char *buffer, int length);

#endif
