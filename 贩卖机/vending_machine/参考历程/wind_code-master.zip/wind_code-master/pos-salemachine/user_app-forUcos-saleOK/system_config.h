#ifndef SYSTEM_CONFIG_H
#define SYSTEM_CONFIG_H
//#include "includes.h"
void System_configAll(void);
void  OpenPeriph(void);
void USART_Config(void);
#endif
