#ifndef VEMDEFINE_H
#define VEMDEFINE_H



#endif
