#ifndef _HANDLE_H_
#define _HANDLE_H_


int send_deduct_money2pos(int money3B, int timeout);

#endif


