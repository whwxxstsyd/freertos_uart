#ifndef MYHASH_H
#define MYHASH_H

unsigned long ELfHash(const unsigned char* name);
unsigned int HashPJW(const char* datum);

#endif /*MYHASH_H*/
